
import React, { useState, useEffect, Suspense, useRef } from 'react';
import { Helmet } from 'react-helmet';
import { Routes, Route, useLocation } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import PublicLayout from '@/components/layouts/PublicLayout';
import AdminLayout from '@/components/layouts/AdminLayout';
import CallCenterLayout from '@/components/layouts/CallCenterLayout';
import LoginPage from '@/pages/LoginPage';
import HomePage from '@/pages/HomePage';
import HotelDetailPage from '@/pages/HotelDetailPage';
import ToursPage from '@/pages/ToursPage';
import AboutPage from '@/pages/AboutPage';
import ContactPage from '@/pages/ContactPage';
import ExperiencesPage from '@/pages/ExperiencesPage';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { I18nextProvider } from 'react-i18next';
import i18n from './i18n';

function App() {
  const { user, loading } = useAuth();
  const [role, setRole] = useState(null);
  const [view, setView] = useState('public');
  const [authLoading, setAuthLoading] = useState(true);
  const setupRan = useRef(false);
  const location = useLocation();

  useEffect(() => {
    const path = location.pathname.toLowerCase();
    if (path.startsWith('/admin')) {
      setView('admin');
    } else if (path.startsWith('/call-center')) {
      setView('callcenter');
    } else {
      setView('public');
    }
  }, [location]);

  useEffect(() => {
    if (setupRan.current || loading) return;
    setupRan.current = true;

    const setupAdmin = async () => {
      const { data: { users }, error: listError } = await supabase.rpc('get_staff_users');
      const adminExists = users?.some(u => u.email === 'technic@lockdownsoft.tech');

      if (!adminExists) {
        const { error: signUpError } = await supabase.auth.signUp({
          email: 'technic@lockdownsoft.tech',
          password: 'Osman.117',
          options: {
            data: { full_name: 'Admin', role: 'admin' }
          }
        });
        if (signUpError && !signUpError.message.includes('User already registered')) {
          console.error("Failed to create admin user:", signUpError.message);
        } else if (!signUpError) {
          console.log("Admin user created successfully.");
        }
      } else {
        console.log("Admin user already exists.");
      }
    };

    const setupStorage = async () => {
      try {
        const { data, error } = await supabase.storage.getBucket('property-images');
        if (error && error.message === 'Bucket not found') {
          const { error: createError } = await supabase.storage.createBucket('property-images', {
            public: true,
            fileSizeLimit: '10MB',
            allowedMimeTypes: ['image/png', 'image/jpeg', 'image/webp'],
          });
          if (createError && !createError.message.includes('The resource already exists')) {
            throw createError;
          }
        }
      } catch (e) {
        console.error("Failed to setup storage bucket:", e.message);
      }
    };

    setupAdmin();
    setupStorage();
  }, [loading]);

  useEffect(() => {
    const fetchUserRole = async () => {
      if (user) {
        const { data, error } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', user.id)
          .single();
        
        if (data) {
          setRole(data.role);
        } else {
          setRole('customer');
        }
      } else {
        setRole(null);
      }
      setAuthLoading(false);
    };

    if (!loading) {
      fetchUserRole();
    }
  }, [user, loading]);

  if (loading || authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-ivory">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-green-light"></div>
      </div>
    );
  }

  const renderLayout = () => {
    if (!user && (view === 'admin' || view === 'callcenter')) {
      return <LoginPage initialTab="signin" />;
    }

    switch (view) {
      case 'admin':
        return <AdminLayout role={role} />;
      case 'callcenter':
        return <CallCenterLayout role={role} />;
      default:
        return (
          <PublicLayout>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/hotel/:slug" element={<HotelDetailPage />} />
              <Route path="/tours" element={<ToursPage />} />
              <Route path="/about" element={<AboutPage />} />
              <Route path="/contact" element={<ContactPage />} />
              <Route path="/experiences" element={<ExperiencesPage />} />
            </Routes>
          </PublicLayout>
        );
    }
  };

  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center bg-ivory">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-green-light"></div>
      </div>
    }>
      <I18nextProvider i18n={i18n}>
        <Helmet>
          <title>HealMedy Travel - Timeless Stays, Curated for You</title>
          <meta name="description" content="Discover and book luxury stays with HealMedy Travel. Experience timeless hospitality and curated collections of exclusive hotels." />
        </Helmet>
        {renderLayout()}
        <Toaster />
      </I18nextProvider>
    </Suspense>
  );
}

export default App;
