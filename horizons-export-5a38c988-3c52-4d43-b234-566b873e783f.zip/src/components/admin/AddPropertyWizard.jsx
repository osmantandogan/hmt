import React, { useState, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useDropzone } from 'react-dropzone';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { X, ArrowLeft, ArrowRight, Check, Loader2, MapPin, UploadCloud, PlusCircle, Trash2, Image as ImageIcon } from 'lucide-react';

const WizardStep = ({ children }) => (
  <motion.div
    initial={{ x: 300, opacity: 0 }}
    animate={{ x: 0, opacity: 1 }}
    exit={{ x: -300, opacity: 0 }}
    transition={{ type: 'spring', stiffness: 300, damping: 30 }}
    className="w-full"
  >
    {children}
  </motion.div>
);

const allAmenities = [
  "spa", "pool_indoor", "pool_outdoor", "gym", "sea_view", "city_view", "parking", 
  "ev_charger", "accessible_rooms", "airport_shuttle", "restaurant", "bar", 
  "meeting_rooms", "kids_club", "pet_friendly", "wifi_free"
];

const Uploader = ({ onUpload, multiple = false }) => {
  const [isUploading, setIsUploading] = useState(false);

  const onDrop = useCallback(async (acceptedFiles) => {
    setIsUploading(true);
    const uploadedFilesInfo = [];

    for (const file of acceptedFiles) {
      const fileName = `${Date.now()}-${file.name.replace(/\s/g, '-')}`;
      const { data, error } = await supabase.storage
        .from('property-images')
        .upload(fileName, file);

      if (error) {
        toast({ variant: 'destructive', title: 'Upload Error', description: error.message });
        console.error('Upload error:', error);
        continue;
      }

      const { data: { publicUrl } } = supabase.storage
        .from('property-images')
        .getPublicUrl(data.path);
      
      uploadedFilesInfo.push({ url: publicUrl, alt_tr: '', alt_en: '' });
    }

    onUpload(multiple ? uploadedFilesInfo : uploadedFilesInfo[0]);
    setIsUploading(false);
  }, [onUpload, multiple]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop, multiple });

  return (
    <div {...getRootProps()} className={`p-6 border-2 border-dashed rounded-lg text-center cursor-pointer transition-colors ${isDragActive ? 'border-primary bg-primary/10' : 'border-gray-300 hover:border-primary'}`}>
      <input {...getInputProps()} />
      {isUploading ? (
        <div className="flex flex-col items-center justify-center">
          <Loader2 className="mx-auto h-12 w-12 text-primary animate-spin" />
          <p className="mt-2 text-sm font-semibold text-primary">Uploading...</p>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center">
          <UploadCloud className="mx-auto h-12 w-12 text-gray-400" />
          <h4 className="mt-2 text-sm font-semibold text-gray-900">Drag & drop or click to upload</h4>
          <p className="text-xs text-gray-500">{multiple ? 'Upload multiple images' : 'Upload a single image'}</p>
        </div>
      )}
    </div>
  );
};

const initialFormData = {
  property: { name_tr: '', name_en: '', slug: '', brand: '', category: 'Hotel', stars: 3, currency: 'TRY', starting_price: 0, description_tr: '', description_en: '', highlight_tags: [], featured: false, status: 'draft', checkin_time: '14:00', checkout_time: '12:00', lat: 41.039, lng: 29.003, timezone: 'Europe/Istanbul', city: '', country: '' },
  contacts: { email: '', phone: '', website: '', address1: '', address2: '', district: '', postal_code: '' },
  policies: { cancellation: { free_until_hours: 48, no_show_penalty: { type: 'percent', value: 100 } }, guarantee: { type: 'none', value: 0, charge_at: 'booking' }, children: { allowed: true, bands: [] }, pet: { allowed: false, fee: 0 }, smoking: { allowed: false }, accessibility: [] },
  taxes: { vat_pct: 10, city_tax_type: 'per_night_per_person', city_tax_value: 0, service_charge_type: 'percent', service_charge_value: 0, included: true, invoice_prefix: '' },
  amenities: [],
  media: { hero_url: '', hero_alt_tr: '', hero_alt_en: '', gallery: [] },
  rooms: [],
  seed: { enabled: false, days: 90, seasons: [], blackouts: [], min_los: 1, max_los: 14 },
  seo: { meta_title_tr: '', meta_desc_tr: '', meta_title_en: '', meta_desc_en: '', og_image: '' }
};

const AddPropertyWizard = ({ isOpen, onClose, propertyToEdit }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState(initialFormData);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const isEditMode = Boolean(propertyToEdit);

  const fetchFullPropertyData = useCallback(async (propertyId) => {
    const { data: propertyData, error: propertyError } = await supabase
      .from('properties')
      .select('*, property_media(*), property_contacts(*), property_policies(*), property_taxes(*)')
      .eq('id', propertyId)
      .single();

    if (propertyError) {
      toast({ variant: 'destructive', title: 'Error fetching property details', description: propertyError.message });
      return null;
    }

    const { data: seoData, error: seoError } = await supabase
      .from('seo_metadata')
      .select('*')
      .eq('entity_type', 'property')
      .eq('entity_id', propertyId)
      .maybeSingle();

    if (seoError) {
      toast({ variant: 'destructive', title: 'Error fetching SEO details', description: seoError.message });
    }

    const { data: roomsData, error: roomsError } = await supabase
      .from('room_types')
      .select('*')
      .eq('property_id', propertyId);

    if (roomsError) {
      toast({ variant: 'destructive', title: 'Error fetching rooms', description: roomsError.message });
      return null;
    }

    const heroImage = propertyData.property_media.find(m => m.is_hero);
    const gallery = propertyData.property_media.filter(m => !m.is_hero && !m.room_type_id).map(g => ({ url: g.url, alt_tr: g.alt_tr, alt_en: g.alt_en }));

    const mappedData = {
      property: {
        name_tr: propertyData.name_tr || '',
        name_en: propertyData.name_en || '',
        slug: propertyData.slug || '',
        brand: propertyData.brand || '',
        category: propertyData.category || 'Hotel',
        stars: propertyData.stars || 3,
        currency: propertyData.currency || 'TRY',
        starting_price: propertyData.starting_price || 0,
        description_tr: propertyData.description_tr || '',
        description_en: propertyData.description_en || '',
        highlight_tags: propertyData.highlight_tags || [],
        featured: propertyData.is_featured || false,
        status: propertyData.status || 'draft',
        checkin_time: propertyData.checkin_time || '14:00',
        checkout_time: propertyData.checkout_time || '12:00',
        lat: propertyData.latitude || 41.039,
        lng: propertyData.longitude || 29.003,
        timezone: propertyData.timezone || 'Europe/Istanbul',
        city: propertyData.city || '',
        country: propertyData.country || ''
      },
      amenities: propertyData.amenities || [],
      media: {
        hero_url: heroImage?.url || '',
        hero_alt_tr: heroImage?.alt_tr || '',
        hero_alt_en: heroImage?.alt_en || '',
        gallery: gallery || []
      },
      contacts: propertyData.property_contacts[0] || initialFormData.contacts,
      policies: propertyData.property_policies[0] ? {
        cancellation: propertyData.property_policies[0].cancellation_json || initialFormData.policies.cancellation,
        guarantee: propertyData.property_policies[0].guarantee_json || initialFormData.policies.guarantee,
        children: propertyData.property_policies[0].children_json || initialFormData.policies.children,
        pet: propertyData.property_policies[0].pet_json || initialFormData.policies.pet,
        smoking: propertyData.property_policies[0].smoking_json || initialFormData.policies.smoking,
        accessibility: propertyData.property_policies[0].accessibility || []
      } : initialFormData.policies,
      taxes: propertyData.property_taxes[0] || initialFormData.taxes,
      rooms: roomsData.map(r => ({ ...r, photos: propertyData.property_media.filter(m => m.room_type_id === r.id).map(p => ({ url: p.url, alt_tr: p.alt_tr, alt_en: p.alt_en })) })) || [],
      seed: initialFormData.seed,
      seo: seoData || initialFormData.seo,
    };
    return mappedData;
  }, []);

  useEffect(() => {
    if (isOpen) {
      if (isEditMode && propertyToEdit) {
        fetchFullPropertyData(propertyToEdit.id).then(data => {
          if (data) setFormData(data);
        });
      } else {
        setFormData(initialFormData);
      }
      setStep(1);
    }
  }, [propertyToEdit, isEditMode, isOpen, fetchFullPropertyData]);

  const totalSteps = 9;

  const handleInputChange = (section, field, value) => {
    setFormData(prev => ({
      ...prev,
      [section]: { ...prev[section], [field]: value }
    }));
  };
  
  const handlePolicyChange = (policy, field, value) => {
    setFormData(prev => ({
      ...prev,
      policies: {
        ...prev.policies,
        [policy]: {
          ...prev.policies[policy],
          [field]: value
        }
      }
    }));
  };

  const handleSlugGeneration = (e) => {
    const value = e.target.value;
    handleInputChange('property', 'name_en', value);
    const slug = value.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    handleInputChange('property', 'slug', slug);
  };

  const handleAmenityToggle = (amenity) => {
    setFormData(prev => {
      const newAmenities = prev.amenities.includes(amenity)
        ? prev.amenities.filter(a => a !== amenity)
        : [...prev.amenities, amenity];
      return { ...prev, amenities: newAmenities };
    });
  };

  const handleRoomChange = (index, field, value) => {
    const newRooms = [...formData.rooms];
    newRooms[index][field] = value;
    setFormData(prev => ({ ...prev, rooms: newRooms }));
  };

  const addRoom = () => {
    setFormData(prev => ({
      ...prev,
      rooms: [...prev.rooms, {
        name_tr: '', name_en: '', size_sqm: 30, view: 'city', bed_config: '1K',
        max_adults: 2, max_children: 0, base_amenities: [], base_price: 1000,
        nr_discount_pct: 10, default_allotment: 10, photos: []
      }]
    }));
  };

  const removeRoom = (index) => {
    const newRooms = formData.rooms.filter((_, i) => i !== index);
    setFormData(prev => ({ ...prev, rooms: newRooms }));
  };

  const handleGalleryImageChange = (index, field, value) => {
    const newGallery = [...formData.media.gallery];
    newGallery[index][field] = value;
    handleInputChange('media', 'gallery', newGallery);
  };

  const removeGalleryImage = (index) => {
    const newGallery = formData.media.gallery.filter((_, i) => i !== index);
    handleInputChange('media', 'gallery', newGallery);
  };
  
  const handleRoomPhotoChange = (roomIndex, photoIndex, field, value) => {
    const newRooms = [...formData.rooms];
    newRooms[roomIndex].photos[photoIndex][field] = value;
    setFormData(prev => ({ ...prev, rooms: newRooms }));
  };

  const removeRoomPhoto = (roomIndex, photoIndex) => {
    const newRooms = [...formData.rooms];
    newRooms[roomIndex].photos = newRooms[roomIndex].photos.filter((_, i) => i !== photoIndex);
    setFormData(prev => ({ ...prev, rooms: newRooms }));
  };

  const nextStep = () => setStep(s => Math.min(s + 1, totalSteps));
  const prevStep = () => setStep(s => Math.max(s - 1, 1));

  const handleSubmit = async (status = 'draft') => {
    setIsSubmitting(true);
    toast({ title: isEditMode ? "Updating Property..." : "Saving Property...", description: "Please wait..." });

    const finalPayload = { ...formData, property: { ...formData.property, status } };
    
    let rpcName = isEditMode ? 'update_property_with_details' : 'create_property_with_defaults';
    let rpcPayload = isEditMode ? { property_id_in: propertyToEdit.id, payload: finalPayload } : { payload: finalPayload };

    const { data, error } = await supabase.rpc(rpcName, rpcPayload);

    setIsSubmitting(false);
    if (error) {
      toast({ variant: 'destructive', title: "Error", description: error.message });
      console.error(error);
    } else {
      toast({ variant: 'default', title: "Success!", description: `Property ${isEditMode ? 'updated' : 'created'}.` });
      onClose(true);
    }
  };

  const renderStepContent = () => {
    switch (step) {
      case 1:
        return (
          <WizardStep key={1}>
            <h3 className="text-xl font-semibold mb-4">1. Identity & Basic Info</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div><Label>Hotel Name (EN)</Label><Input value={formData.property.name_en} onChange={handleSlugGeneration} placeholder="Mandarin-Inspired Istanbul" /></div>
                <div><Label>Hotel Name (TR)</Label><Input value={formData.property.name_tr} onChange={(e) => handleInputChange('property', 'name_tr', e.target.value)} placeholder="Mandarin Esintili İstanbul" /></div>
              </div>
              <div><Label>Slug</Label><Input value={formData.property.slug} onChange={(e) => handleInputChange('property', 'slug', e.target.value)} readOnly placeholder="mandarin-istanbul" /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><Label>Star Rating</Label><Select value={formData.property.stars.toString()} onValueChange={v => handleInputChange('property', 'stars', parseInt(v))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{[1,2,3,4,5].map(s => <SelectItem key={s} value={s.toString()}>{s} Stars</SelectItem>)}</SelectContent></Select></div>
                <div><Label>Category</Label><Select value={formData.property.category} onValueChange={v => handleInputChange('property', 'category', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{['Hotel', 'Resort', 'Boutique', 'City', 'Apart'].map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><Label>Default Currency</Label><Select value={formData.property.currency} onValueChange={v => handleInputChange('property', 'currency', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="TRY">TRY</SelectItem><SelectItem value="EUR">EUR</SelectItem></SelectContent></Select></div>
                <div><Label>Starting Price</Label><Input type="number" value={formData.property.starting_price} onChange={(e) => handleInputChange('property', 'starting_price', parseFloat(e.target.value))} /></div>
              </div>
              <div><Label>Long Description (EN)</Label><Textarea value={formData.property.description_en} onChange={(e) => handleInputChange('property', 'description_en', e.target.value)} /></div>
              <div className="flex items-center space-x-2"><Switch id="featured" checked={formData.property.featured} onCheckedChange={v => handleInputChange('property', 'featured', v)} /><Label htmlFor="featured">Feature on Homepage?</Label></div>
            </div>
          </WizardStep>
        );
      case 2:
        return (
          <WizardStep key={2}>
            <h3 className="text-xl font-semibold mb-4">2. Location & Contact</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div><Label>City</Label><Input value={formData.property.city} onChange={(e) => handleInputChange('property', 'city', e.target.value)} placeholder="Istanbul" /></div>
                <div><Label>Country</Label><Input value={formData.property.country} onChange={(e) => handleInputChange('property', 'country', e.target.value)} placeholder="Turkey" /></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><Label>Timezone</Label><Input value={formData.property.timezone} onChange={(e) => handleInputChange('property', 'timezone', e.target.value)} placeholder="Europe/Istanbul" /></div>
              </div>
              <div className="p-4 border rounded-lg">
                <Label>Map Location</Label>
                <div className="h-40 bg-slate-200 rounded-md my-2 flex items-center justify-center text-slate-500">
                  <MapPin className="w-8 h-8" />
                  <p>Map Picker Coming Soon</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div><Label>Latitude</Label><Input type="number" value={formData.property.lat} onChange={(e) => handleInputChange('property', 'lat', parseFloat(e.target.value))} /></div>
                  <div><Label>Longitude</Label><Input type="number" value={formData.property.lng} onChange={(e) => handleInputChange('property', 'lng', parseFloat(e.target.value))} /></div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><Label>Primary Email</Label><Input type="email" value={formData.contacts.email} onChange={(e) => handleInputChange('contacts', 'email', e.target.value)} placeholder="info@hotel.com" /></div>
                <div><Label>Primary Phone</Label><Input type="tel" value={formData.contacts.phone} onChange={(e) => handleInputChange('contacts', 'phone', e.target.value)} placeholder="+90..." /></div>
              </div>
              <div><Label>Website URL</Label><Input type="url" value={formData.contacts.website} onChange={(e) => handleInputChange('contacts', 'website', e.target.value)} placeholder="https://hotel.com" /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><Label>Check-in Time</Label><Input type="time" value={formData.property.checkin_time} onChange={(e) => handleInputChange('property', 'checkin_time', e.target.value)} /></div>
                <div><Label>Check-out Time</Label><Input type="time" value={formData.property.checkout_time} onChange={(e) => handleInputChange('property', 'checkout_time', e.target.value)} /></div>
              </div>
            </div>
          </WizardStep>
        );
      case 3:
        return (
          <WizardStep key={3}>
            <h3 className="text-xl font-semibold mb-4">3. Policies</h3>
            <div className="space-y-6">
              <div className="p-4 border rounded-lg space-y-2">
                <h4 className="font-semibold">Cancellation Policy</h4>
                <Label>Free cancellation until (hours before check-in)</Label>
                <Input type="number" value={formData.policies.cancellation.free_until_hours} onChange={(e) => handlePolicyChange('cancellation', 'free_until_hours', parseInt(e.target.value))} />
                <Label>No-show Penalty</Label>
                <div className="flex gap-2">
                  <Select value={formData.policies.cancellation.no_show_penalty.type} onValueChange={v => handlePolicyChange('cancellation', 'no_show_penalty', { ...formData.policies.cancellation.no_show_penalty, type: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent><SelectItem value="percent">Percent</SelectItem><SelectItem value="nights">First Night(s)</SelectItem></SelectContent>
                  </Select>
                  <Input type="number" value={formData.policies.cancellation.no_show_penalty.value} onChange={(e) => handlePolicyChange('cancellation', 'no_show_penalty', { ...formData.policies.cancellation.no_show_penalty, value: parseInt(e.target.value) })} />
                </div>
              </div>
              <div className="p-4 border rounded-lg space-y-2">
                <h4 className="font-semibold">Pet Policy</h4>
                <div className="flex items-center space-x-2">
                  <Switch id="pet-allowed" checked={formData.policies.pet.allowed} onCheckedChange={v => handlePolicyChange('pet', 'allowed', v)} />
                  <Label htmlFor="pet-allowed">Pets Allowed</Label>
                </div>
                {formData.policies.pet.allowed && (
                  <div>
                    <Label>Pet Fee (per stay)</Label>
                    <Input type="number" value={formData.policies.pet.fee} onChange={(e) => handlePolicyChange('pet', 'fee', parseInt(e.target.value))} />
                  </div>
                )}
              </div>
              <div className="p-4 border rounded-lg space-y-2">
                <h4 className="font-semibold">Smoking Policy</h4>
                <div className="flex items-center space-x-2">
                  <Switch id="smoking-allowed" checked={formData.policies.smoking.allowed} onCheckedChange={v => handlePolicyChange('smoking', 'allowed', v)} />
                  <Label htmlFor="smoking-allowed">Smoking Allowed in Designated Areas</Label>
                </div>
              </div>
            </div>
          </WizardStep>
        );
      case 4:
        return (
          <WizardStep key={4}>
            <h3 className="text-xl font-semibold mb-4">4. Taxes & Fees</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div><Label>VAT/KDV (%)</Label><Input type="number" value={formData.taxes.vat_pct} onChange={e => handleInputChange('taxes', 'vat_pct', parseFloat(e.target.value))} /></div>
                <div><Label>Invoice Prefix</Label><Input value={formData.taxes.invoice_prefix} onChange={e => handleInputChange('taxes', 'invoice_prefix', e.target.value)} placeholder="HM-IST-" /></div>
              </div>
              <div className="p-4 border rounded-lg space-y-2">
                <h4 className="font-semibold">City/Accommodation Tax</h4>
                <Select value={formData.taxes.city_tax_type} onValueChange={v => handleInputChange('taxes', 'city_tax_type', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="per_person_per_night">Per Person / Per Night</SelectItem>
                    <SelectItem value="per_room_per_night">Per Room / Per Night</SelectItem>
                    <SelectItem value="percent_of_total">Percent of Total</SelectItem>
                  </SelectContent>
                </Select>
                <Input type="number" value={formData.taxes.city_tax_value} onChange={e => handleInputChange('taxes', 'city_tax_value', parseFloat(e.target.value))} />
              </div>
              <div className="p-4 border rounded-lg space-y-2">
                <h4 className="font-semibold">Service Charge</h4>
                <Select value={formData.taxes.service_charge_type} onValueChange={v => handleInputChange('taxes', 'service_charge_type', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percent">Percent</SelectItem>
                    <SelectItem value="fixed">Fixed Amount</SelectItem>
                  </SelectContent>
                </Select>
                <Input type="number" value={formData.taxes.service_charge_value} onChange={e => handleInputChange('taxes', 'service_charge_value', parseFloat(e.target.value))} />
              </div>
              <div className="flex items-center space-x-2"><Switch id="included" checked={formData.taxes.included} onCheckedChange={v => handleInputChange('taxes', 'included', v)} /><Label htmlFor="included">Taxes and fees are included in the price</Label></div>
            </div>
          </WizardStep>
        );
      case 5:
        return (
          <WizardStep key={5}>
            <h3 className="text-xl font-semibold mb-4">5. Amenities</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {allAmenities.map(amenity => (
                <div key={amenity} className="flex items-center space-x-2">
                  <Checkbox id={`amenity-${amenity}`} checked={formData.amenities.includes(amenity)} onCheckedChange={() => handleAmenityToggle(amenity)} />
                  <Label htmlFor={`amenity-${amenity}`} className="capitalize">{amenity.replace(/_/g, ' ')}</Label>
                </div>
              ))}
            </div>
          </WizardStep>
        );
      case 6:
        return (
          <WizardStep key={6}>
            <h3 className="text-xl font-semibold mb-4">6. Media</h3>
            <div className="space-y-6">
              <div>
                <Label>Hero Image</Label>
                {formData.media.hero_url ? (
                  <div className="mt-2 relative w-full h-64">
                    <img src={formData.media.hero_url} alt="Hero image preview" className="w-full h-full object-cover rounded-lg" />
                    <div className="absolute bottom-2 left-2 right-2 p-2 bg-black/50 rounded-md">
                      <Input className="bg-transparent text-white border-white/50" placeholder="Alt Text (EN)" value={formData.media.hero_alt_en} onChange={e => handleInputChange('media', 'hero_alt_en', e.target.value)} />
                    </div>
                    <Button variant="destructive" size="icon" className="absolute top-2 right-2" onClick={() => { handleInputChange('media', 'hero_url', ''); handleInputChange('media', 'hero_alt_en', ''); }}><Trash2 className="w-4 h-4" /></Button>
                  </div>
                ) : (
                  <Uploader onUpload={(file) => { handleInputChange('media', 'hero_url', file.url); handleInputChange('media', 'hero_alt_en', file.alt_en); }} />
                )}
              </div>
              <div>
                <Label>Gallery Images</Label>
                <div className="mt-2 grid grid-cols-2 md:grid-cols-4 gap-4">
                  {formData.media.gallery.map((img, index) => (
                    <div key={index} className="relative group">
                      <img src={img.url} alt={`Gallery image ${index + 1}`} className="w-full h-32 object-cover rounded-lg" />
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Button variant="destructive" size="icon" onClick={() => removeGalleryImage(index)}><Trash2 className="w-4 h-4" /></Button>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-4">
                  <Uploader onUpload={(files) => handleInputChange('media', 'gallery', [...formData.media.gallery, ...files])} multiple />
                </div>
              </div>
            </div>
          </WizardStep>
        );
      case 7:
        return (
          <WizardStep key={7}>
            <h3 className="text-xl font-semibold mb-4">7. Room Types (Quick Setup)</h3>
            <div className="space-y-4">
              {formData.rooms.map((room, index) => (
                <div key={room.id || index} className="p-4 border rounded-lg relative">
                  <h4 className="font-semibold mb-2">Room {index + 1}</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <Input placeholder="Name (EN)" value={room.name_en} onChange={e => handleRoomChange(index, 'name_en', e.target.value)} />
                    <Input placeholder="Name (TR)" value={room.name_tr} onChange={e => handleRoomChange(index, 'name_tr', e.target.value)} />
                    <Input type="number" placeholder="Size (m²)" value={room.size_sqm} onChange={e => handleRoomChange(index, 'size_sqm', parseFloat(e.target.value))} />
                    <Input placeholder="View (sea/city)" value={room.view} onChange={e => handleRoomChange(index, 'view', e.target.value)} />
                    <Input type="number" placeholder="Base Rate (BAR)" value={room.base_price} onChange={e => handleRoomChange(index, 'base_price', parseFloat(e.target.value))} />
                    <Input type="number" placeholder="Default Allotment" value={room.default_allotment} onChange={e => handleRoomChange(index, 'default_allotment', parseInt(e.target.value))} />
                  </div>
                  <div className="mt-4">
                    <Label>Room Photos</Label>
                    <div className="mt-2 grid grid-cols-4 gap-2">
                      {room.photos.map((photo, photoIndex) => (
                        <div key={photoIndex} className="relative group">
                          <img src={photo.url} alt={`Room photo ${photoIndex + 1}`} className="w-full h-20 object-cover rounded-md" />
                           <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                            <Button variant="destructive" size="icon" className="h-8 w-8" onClick={() => removeRoomPhoto(index, photoIndex)}><Trash2 className="w-4 h-4" /></Button>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="mt-2">
                      <Uploader onUpload={(files) => handleRoomChange(index, 'photos', [...room.photos, ...files])} multiple />
                    </div>
                  </div>
                  <Button variant="destructive" size="icon" className="absolute top-2 right-2" onClick={() => removeRoom(index)}><Trash2 className="w-4 h-4" /></Button>
                </div>
              ))}
              <Button variant="outline" onClick={addRoom}><PlusCircle className="w-4 h-4 mr-2" /> Add Room Type</Button>
            </div>
          </WizardStep>
        );
      case 8:
        return (
          <WizardStep key={8}>
            <h3 className="text-xl font-semibold mb-4">8. Price & Inventory Seed</h3>
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch id="seed-enabled" checked={formData.seed.enabled} onCheckedChange={v => handleInputChange('seed', 'enabled', v)} />
                <Label htmlFor="seed-enabled">Seed inventory for the next 90 days?</Label>
              </div>
              {formData.seed.enabled && (
                <div className="p-4 border rounded-lg space-y-4">
                  <p className="text-sm text-muted-foreground">This will create inventory for all rooms. Seasonal adjustments and blackout dates are coming soon!</p>
                  <div className="grid grid-cols-2 gap-4">
                    <div><Label>Min Length of Stay</Label><Input type="number" value={formData.seed.min_los} onChange={e => handleInputChange('seed', 'min_los', parseInt(e.target.value))} /></div>
                    <div><Label>Max Length of Stay</Label><Input type="number" value={formData.seed.max_los} onChange={e => handleInputChange('seed', 'max_los', parseInt(e.target.value))} /></div>
                  </div>
                </div>
              )}
            </div>
          </WizardStep>
        );
      case 9:
        return (
          <WizardStep key={9}>
            <h3 className="text-xl font-semibold mb-4">9. SEO & Publishing</h3>
            <div className="space-y-4">
              <div><Label>Meta Title (EN)</Label><Input value={formData.seo.meta_title_en} onChange={e => handleInputChange('seo', 'meta_title_en', e.target.value)} /></div>
              <div><Label>Meta Description (EN)</Label><Textarea value={formData.seo.meta_desc_en} onChange={e => handleInputChange('seo', 'meta_desc_en', e.target.value)} /></div>
              <div><Label>Meta Title (TR)</Label><Input value={formData.seo.meta_title_tr} onChange={e => handleInputChange('seo', 'meta_title_tr', e.target.value)} /></div>
              <div><Label>Meta Description (TR)</Label><Textarea value={formData.seo.meta_desc_tr} onChange={e => handleInputChange('seo', 'meta_desc_tr', e.target.value)} /></div>
              <div className="pt-6 text-center">
                <h4 className="text-lg font-semibold">You're all set!</h4>
                <p className="text-muted-foreground">You can save as a draft to continue later, or publish now to make it live.</p>
              </div>
            </div>
          </WizardStep>
        );
      default:
        return null;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose(false)}>
      <DialogContent className="max-w-4xl h-[90vh] flex flex-col p-0">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle className="text-2xl">{isEditMode ? 'Edit Property' : 'Add New Property'} Wizard</DialogTitle>
          <DialogDescription>Follow the steps to {isEditMode ? 'update the' : 'add a new'} hotel.</DialogDescription>
        </DialogHeader>
        <div className="flex-1 overflow-y-auto p-6">
          <AnimatePresence mode="wait">
            {renderStepContent()}
          </AnimatePresence>
        </div>
        <div className="border-t p-4 flex justify-between items-center bg-slate-50">
          <div>
            <Button variant="ghost" onClick={() => handleSubmit('draft')} disabled={isSubmitting}>Save as Draft</Button>
          </div>
          <div className="flex items-center gap-2">
            <div className="text-sm text-muted-foreground">Step {step} of {totalSteps}</div>
            <Button variant="outline" onClick={prevStep} disabled={step === 1 || isSubmitting}>
              <ArrowLeft className="w-4 h-4 mr-2" /> Previous
            </Button>
            {step < totalSteps && (
              <Button onClick={nextStep} disabled={isSubmitting}>
                Next <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            )}
            {step === totalSteps && (
              <Button onClick={() => handleSubmit('active')} disabled={isSubmitting} className="bg-green-600 hover:bg-green-700">
                {isSubmitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Check className="w-4 h-4 mr-2" />}
                {isEditMode ? 'Update & Publish' : 'Finish & Publish'}
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AddPropertyWizard;