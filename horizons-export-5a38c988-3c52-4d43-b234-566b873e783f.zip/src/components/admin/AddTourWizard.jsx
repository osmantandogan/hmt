
import React, { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Check, Loader2, Plus, Trash2, UploadCloud } from 'lucide-react';
import { useDropzone } from 'react-dropzone';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useBookingData } from '@/hooks/useBookingData';
import { supabase } from '@/lib/customSupabaseClient';
import { toast } from '@/components/ui/use-toast';

const steps = [
  { id: 1, name: 'Overview' },
  { id: 2, name: 'Details' },
  { id: 3, name: 'Media' },
  { id: 4, name: 'Scheduling' },
  { id: 5, name: 'Pricing' },
  { id: 6, name: 'Add-ons' },
  { id: 7, name: 'SEO' },
  { id: 8, name: 'Publish' },
];

const ListInput = ({ label, value, onChange }) => {
  const items = Array.isArray(value) ? value : (value ? value.split('\n') : []);
  const handleChange = (e) => {
    onChange(e.target.value.split('\n'));
  };
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <Textarea
        value={items.join('\n')}
        onChange={handleChange}
        placeholder="Enter one item per line"
        rows={4}
      />
    </div>
  );
};

const AddTourWizard = ({ onClose }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    tour: {
      name_tr: '', name_en: '', slug: '', category: '', duration_minutes: 60,
      is_private_bool: false, min_group_size: 1, max_group_size: 10,
      status: 'draft', city: '', country: '', meeting_point_tr: '', meeting_point_en: ''
    },
    details: {
      highlights_tr: [], highlights_en: [], includes_tr: [], includes_en: [],
      excludes_tr: [], excludes_en: [], what_to_bring_tr: [], what_to_bring_en: []
    },
    media: { hero_url: '', gallery: [] },
    schedules: [{ rrule_text: 'FREQ=DAILY', start_time_local: '09:00', capacity_per_session: 20, cutoff_hours_before: 24 }],
    pricing: [{ season_name: 'Default', base_price_adult: 100, base_price_child: 50, base_price_infant: 0, currency: 'EUR' }],
    addons: [],
    seo: { meta_title_tr: '', meta_desc_tr: '', meta_title_en: '', meta_desc_en: '' }
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { tourCategories } = useBookingData();

  const handleInputChange = (section, field, value, index) => {
    setFormData(prev => {
      const newState = { ...prev };
      if (index !== undefined) {
        const newArray = [...(newState[section] || [])];
        newArray[index] = { ...newArray[index], [field]: value };
        newState[section] = newArray;
      } else {
        newState[section] = { ...newState[section], [field]: value };
      }
      return newState;
    });
  };

  const handleSlugify = (e) => {
    const value = e.target.value;
    handleInputChange('tour', 'name_en', value);
    const slug = value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    handleInputChange('tour', 'slug', slug);
  };

  const addListItem = (section, newItem) => {
    setFormData(prev => {
        const currentList = prev[section] || [];
        return {
            ...prev,
            [section]: [...currentList, newItem]
        };
    });
  };
  
  const removeListItem = (section, index) => {
    setFormData(prev => ({
      ...prev,
      [section]: prev[section].filter((_, i) => i !== index)
    }));
  };

  const onDrop = useCallback(async (acceptedFiles, field, isMultiple) => {
    if (!acceptedFiles || acceptedFiles.length === 0) return;

    const uploadFile = async (file) => {
      const fileName = `${Date.now()}-${file.name.replace(/\s/g, '-')}`;
      const { error: uploadError } = await supabase.storage
        .from('property-images')
        .upload(fileName, file);

      if (uploadError) {
        toast({ variant: 'destructive', title: 'Upload failed', description: uploadError.message });
        return null;
      }

      const { data: { publicUrl } } = supabase.storage.from('property-images').getPublicUrl(fileName);
      return publicUrl;
    };

    if (isMultiple) {
      const newUrls = await Promise.all(acceptedFiles.map(uploadFile));
      const validUrls = newUrls.filter(url => url !== null);
      setFormData(prev => ({
        ...prev,
        media: {
          ...prev.media,
          [field]: [...(prev.media[field] || []), ...validUrls.map(url => ({ url, alt_tr: '', alt_en: '' }))]
        }
      }));
    } else {
      const publicUrl = await uploadFile(acceptedFiles[0]);
      if (publicUrl) {
        handleInputChange('media', field, publicUrl);
      }
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });

  const nextStep = () => setCurrentStep(s => Math.min(s + 1, steps.length));
  const prevStep = () => setCurrentStep(s => Math.max(s - 1, 1));

  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    const { data, error } = await supabase.rpc('create_tour_with_details', { payload: formData });
    
    if (error) {
      toast({
        variant: 'destructive',
        title: 'Error creating tour',
        description: error.message,
      });
      console.error(error);
    } else {
      toast({
        title: 'Tour Created Successfully!',
        description: `Tour "${formData.tour.name_en}" has been added.`,
      });
      onClose(true);
    }
    
    setIsSubmitting(false);
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1: // Overview
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="name_en">Tour Name (EN)</Label>
              <Input id="name_en" value={formData.tour.name_en} onChange={handleSlugify} placeholder="e.g., Bosphorus Sunset Cruise" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="slug">URL Slug</Label>
              <Input id="slug" value={formData.tour.slug} onChange={(e) => handleInputChange('tour', 'slug', e.target.value)} placeholder="e.g., bosphorus-sunset-cruise" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="name_tr">Tour Name (TR)</Label>
              <Input id="name_tr" value={formData.tour.name_tr} onChange={(e) => handleInputChange('tour', 'name_tr', e.target.value)} placeholder="e.g., Boğazda Gün Batımı Turu" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select onValueChange={(value) => handleInputChange('tour', 'category', value)} value={formData.tour.category}>
                <SelectTrigger><SelectValue placeholder="Select a category" /></SelectTrigger>
                <SelectContent>
                  {tourCategories.map(cat => <SelectItem key={cat.key} value={cat.key}>{cat.name_en}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="duration">Duration (minutes)</Label>
              <Input id="duration" type="number" value={formData.tour.duration_minutes} onChange={(e) => handleInputChange('tour', 'duration_minutes', parseInt(e.target.value))} />
            </div>
            <div className="flex items-center space-x-2 pt-8">
              <Switch id="is_private" checked={formData.tour.is_private_bool} onCheckedChange={(checked) => handleInputChange('tour', 'is_private_bool', checked)} />
              <Label htmlFor="is_private">This is a private tour</Label>
            </div>
             <div className="space-y-2">
              <Label htmlFor="city">City</Label>
              <Input id="city" value={formData.tour.city} onChange={(e) => handleInputChange('tour', 'city', e.target.value)} placeholder="e.g., Istanbul" />
            </div>
             <div className="space-y-2">
              <Label htmlFor="country">Country</Label>
              <Input id="country" value={formData.tour.country} onChange={(e) => handleInputChange('tour', 'country', e.target.value)} placeholder="e.g., Turkey" />
            </div>
          </div>
        );
      case 2: // Details
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ListInput label="Highlights (EN)" value={formData.details.highlights_en} onChange={(v) => handleInputChange('details', 'highlights_en', v)} />
            <ListInput label="Highlights (TR)" value={formData.details.highlights_tr} onChange={(v) => handleInputChange('details', 'highlights_tr', v)} />
            <ListInput label="Includes (EN)" value={formData.details.includes_en} onChange={(v) => handleInputChange('details', 'includes_en', v)} />
            <ListInput label="Includes (TR)" value={formData.details.includes_tr} onChange={(v) => handleInputChange('details', 'includes_tr', v)} />
            <ListInput label="Excludes (EN)" value={formData.details.excludes_en} onChange={(v) => handleInputChange('details', 'excludes_en', v)} />
            <ListInput label="Excludes (TR)" value={formData.details.excludes_tr} onChange={(v) => handleInputChange('details', 'excludes_tr', v)} />
            <ListInput label="What to Bring (EN)" value={formData.details.what_to_bring_en} onChange={(v) => handleInputChange('details', 'what_to_bring_en', v)} />
            <ListInput label="What to Bring (TR)" value={formData.details.what_to_bring_tr} onChange={(v) => handleInputChange('details', 'what_to_bring_tr', v)} />
          </div>
        );
      case 3: // Media
        return (
          <div>
            <Label>Hero Image</Label>
            <div {...getRootProps({ onDrop: (files) => onDrop(files, 'hero_url', false) })} className={`mt-2 flex justify-center rounded-lg border border-dashed border-gray-900/25 px-6 py-10 ${isDragActive ? 'bg-blue-50' : ''}`}>
              <div className="text-center">
                <UploadCloud className="mx-auto h-12 w-12 text-gray-400" />
                <div className="mt-4 flex text-sm leading-6 text-gray-600">
                  <p className="pl-1">Drag & drop a file or click to upload</p>
                </div>
                <p className="text-xs leading-5 text-gray-600">PNG, JPG, WEBP up to 10MB</p>
              </div>
              <input {...getInputProps()} className="sr-only" />
            </div>
            {formData.media.hero_url && <img src={formData.media.hero_url} alt="Hero preview" className="mt-4 h-32 w-auto rounded-lg"  src="https://images.unsplash.com/photo-1595872018818-97555653a011" />}
            
            <Label className="mt-6 block">Gallery Images</Label>
            <div {...getRootProps({ onDrop: (files) => onDrop(files, 'gallery', true) })} className={`mt-2 flex justify-center rounded-lg border border-dashed border-gray-900/25 px-6 py-10 ${isDragActive ? 'bg-blue-50' : ''}`}>
              <div className="text-center">
                <UploadCloud className="mx-auto h-12 w-12 text-gray-400" />
                <p>Drag & drop files or click to upload</p>
              </div>
              <input {...getInputProps()} className="sr-only" />
            </div>
            <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
              {formData.media.gallery.map((img, index) => (
                <div key={index} className="relative">
                  <img src={img.url} alt={`Gallery preview ${index + 1}`} className="h-32 w-full object-cover rounded-lg"  src="https://images.unsplash.com/photo-1595872018818-97555653a011" />
                  <Button variant="destructive" size="icon" className="absolute top-1 right-1 h-6 w-6" onClick={() => removeListItem('media', 'gallery', index)}><Trash2 className="h-4 w-4" /></Button>
                </div>
              ))}
            </div>
          </div>
        );
      case 4: // Scheduling
        return (
          <div className="space-y-6">
            {formData.schedules.map((schedule, index) => (
              <div key={index} className="p-4 border rounded-lg relative">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Recurrence Rule (RRULE)</Label>
                    <Input value={schedule.rrule_text} onChange={(e) => handleInputChange('schedules', 'rrule_text', e.target.value, index)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Start Time</Label>
                    <Input type="time" value={schedule.start_time_local} onChange={(e) => handleInputChange('schedules', 'start_time_local', e.target.value, index)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Capacity per Session</Label>
                    <Input type="number" value={schedule.capacity_per_session} onChange={(e) => handleInputChange('schedules', 'capacity_per_session', parseInt(e.target.value), index)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Cut-off (hours before)</Label>
                    <Input type="number" value={schedule.cutoff_hours_before} onChange={(e) => handleInputChange('schedules', 'cutoff_hours_before', parseInt(e.target.value), index)} />
                  </div>
                </div>
                {formData.schedules.length > 1 && <Button variant="destructive" size="icon" className="absolute top-2 right-2 h-7 w-7" onClick={() => removeListItem('schedules', index)}><Trash2 className="h-4 w-4" /></Button>}
              </div>
            ))}
            <Button variant="outline" onClick={() => addListItem('schedules', { rrule_text: 'FREQ=DAILY', start_time_local: '14:00', capacity_per_session: 15, cutoff_hours_before: 12 })}><Plus className="w-4 h-4 mr-2" />Add Schedule</Button>
          </div>
        );
      case 5: // Pricing
        return (
          <div className="space-y-6">
            {formData.pricing.map((price, index) => (
              <div key={index} className="p-4 border rounded-lg relative">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Season Name</Label>
                    <Input value={price.season_name} onChange={(e) => handleInputChange('pricing', 'season_name', e.target.value, index)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Currency</Label>
                    <Select value={price.currency} onValueChange={(v) => handleInputChange('pricing', 'currency', v, index)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent><SelectItem value="EUR">EUR</SelectItem><SelectItem value="USD">USD</SelectItem><SelectItem value="TRY">TRY</SelectItem></SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Adult Price</Label>
                    <Input type="number" value={price.base_price_adult} onChange={(e) => handleInputChange('pricing', 'base_price_adult', parseFloat(e.target.value), index)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Child Price</Label>
                    <Input type="number" value={price.base_price_child} onChange={(e) => handleInputChange('pricing', 'base_price_child', parseFloat(e.target.value), index)} />
                  </div>
                   <div className="space-y-2">
                    <Label>Infant Price</Label>
                    <Input type="number" value={price.base_price_infant} onChange={(e) => handleInputChange('pricing', 'base_price_infant', parseFloat(e.target.value), index)} />
                  </div>
                </div>
                {formData.pricing.length > 1 && <Button variant="destructive" size="icon" className="absolute top-2 right-2 h-7 w-7" onClick={() => removeListItem('pricing', index)}><Trash2 className="h-4 w-4" /></Button>}
              </div>
            ))}
            <Button variant="outline" onClick={() => addListItem('pricing', { season_name: 'High Season', base_price_adult: 150, base_price_child: 75, base_price_infant: 0, currency: 'EUR' })}><Plus className="w-4 h-4 mr-2" />Add Price Rule</Button>
          </div>
        );
      case 6: // Add-ons
        return (
          <div className="space-y-6">
            {formData.addons.map((addon, index) => (
              <div key={index} className="p-4 border rounded-lg relative">
                <div className="grid grid-cols-2 gap-4">
                  <Input placeholder="Code (e.g., PHOTO_PKG)" value={addon.code} onChange={(e) => handleInputChange('addons', 'code', e.target.value, index)} />
                  <Input placeholder="Name (EN)" value={addon.name_en} onChange={(e) => handleInputChange('addons', 'name_en', e.target.value, index)} />
                  <Input placeholder="Name (TR)" value={addon.name_tr} onChange={(e) => handleInputChange('addons', 'name_tr', e.target.value, index)} />
                  <Input type="number" placeholder="Price" value={addon.price} onChange={(e) => handleInputChange('addons', 'price', parseFloat(e.target.value), index)} />
                  <Select value={addon.pricing_mode} onValueChange={(v) => handleInputChange('addons', 'pricing_mode', v, index)}>
                    <SelectTrigger><SelectValue placeholder="Pricing Mode" /></SelectTrigger>
                    <SelectContent><SelectItem value="per_person">Per Person</SelectItem><SelectItem value="per_booking">Per Booking</SelectItem></SelectContent>
                  </Select>
                </div>
                <Button variant="destructive" size="icon" className="absolute top-2 right-2 h-7 w-7" onClick={() => removeListItem('addons', index)}><Trash2 className="h-4 w-4" /></Button>
              </div>
            ))}
            <Button variant="outline" onClick={() => addListItem('addons', { code: '', name_en: '', name_tr: '', price: 10, currency: 'EUR', pricing_mode: 'per_person' })}><Plus className="w-4 h-4 mr-2" />Add Add-on</Button>
          </div>
        );
      case 7: // SEO
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Meta Title (EN)</Label>
              <Input value={formData.seo.meta_title_en} onChange={(e) => handleInputChange('seo', 'meta_title_en', e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Meta Description (EN)</Label>
              <Textarea value={formData.seo.meta_desc_en} onChange={(e) => handleInputChange('seo', 'meta_desc_en', e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Meta Title (TR)</Label>
              <Input value={formData.seo.meta_title_tr} onChange={(e) => handleInputChange('seo', 'meta_title_tr', e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Meta Description (TR)</Label>
              <Textarea value={formData.seo.meta_desc_tr} onChange={(e) => handleInputChange('seo', 'meta_desc_tr', e.target.value)} />
            </div>
          </div>
        );
      case 8: // Publish
        return (
          <div className="text-center">
            <h3 className="text-2xl font-bold">Ready to Publish?</h3>
            <p className="mt-2 text-gray-600">Review all the information you've entered. Once you publish, the tour will be created in draft mode. You can activate it from the main tour list.</p>
            <div className="mt-6 bg-gray-50 p-4 rounded-lg text-left max-h-80 overflow-y-auto">
              <h4 className="font-semibold">Summary:</h4>
              <pre className="text-sm whitespace-pre-wrap">{JSON.stringify({ tour: formData.tour, schedules: formData.schedules.length, prices: formData.pricing.length }, null, 2)}</pre>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-1">
      <div className="flex items-center gap-4 mb-8">
        <Button variant="ghost" size="icon" onClick={() => onClose(false)}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-3xl font-bold text-ebony">Add New Tour</h1>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        <div className="w-full lg:w-1/4">
          <ol className="flex flex-wrap lg:flex-col gap-2 lg:space-y-4">
            {steps.map((step) => (
              <li key={step.id} className="flex items-center gap-3 cursor-pointer" onClick={() => setCurrentStep(step.id)}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0 ${
                  currentStep > step.id ? 'bg-green-500 text-white' :
                  currentStep === step.id ? 'bg-blue-600 text-white' :
                  'bg-gray-200 text-gray-600'
                }`}>
                  {currentStep > step.id ? <Check className="w-5 h-5" /> : step.id}
                </div>
                <span className={`font-medium ${currentStep === step.id ? 'text-blue-600' : 'text-gray-700'}`}>
                  {step.name}
                </span>
              </li>
            ))}
          </ol>
        </div>

        <div className="w-full lg:w-3/4 bg-white p-8 rounded-2xl shadow-lg">
          <h2 className="text-2xl font-bold mb-6 border-b pb-4">{steps.find(s => s.id === currentStep).name}</h2>
          <div className="min-h-[300px]">
            {renderStepContent()}
          </div>
          <div className="flex justify-between mt-8 pt-6 border-t">
            <Button variant="outline" onClick={prevStep} disabled={currentStep === 1}>
              Previous
            </Button>
            {currentStep < steps.length ? (
              <Button onClick={nextStep}>Next</Button>
            ) : (
              <Button onClick={handleSubmit} disabled={isSubmitting}>
                {isSubmitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                Finish & Create Draft
              </Button>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default AddTourWizard;
