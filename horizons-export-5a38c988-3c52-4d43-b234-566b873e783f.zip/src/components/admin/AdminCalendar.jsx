
import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, BedDouble, Loader2, X, Minus, Plus, Edit, Save, Ban, ArrowRight, ArrowLeft, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useBookingData } from '@/hooks/useBookingData';
import { supabase } from '@/lib/customSupabaseClient';
import { toast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';

const AdminCalendar = () => {
  const { properties, rooms, loading: contextLoading } = useBookingData();
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedProperty, setSelectedProperty] = useState(null);
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [calendarData, setCalendarData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [editingCell, setEditingCell] = useState(null);
  const [editValue, setEditValue] = useState('');

  const firstDayOfMonth = useMemo(() => new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1), [currentMonth]);
  const lastDayOfMonth = useMemo(() => new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0), [currentMonth]);

  useEffect(() => {
    if (properties.length > 0 && !selectedProperty) {
      setSelectedProperty(properties[0].id);
    }
  }, [properties, selectedProperty]);

  const propertyRooms = useMemo(() => {
    return rooms.filter(r => r.property_id === selectedProperty);
  }, [rooms, selectedProperty]);

  useEffect(() => {
    if (propertyRooms.length > 0 && !selectedRoom) {
      setSelectedRoom(propertyRooms[0].id);
    } else if (propertyRooms.length === 0) {
      setSelectedRoom(null);
    }
  }, [propertyRooms, selectedRoom]);

  useEffect(() => {
    const fetchCalendarData = async () => {
      if (!selectedProperty || !selectedRoom) return;

      setLoading(true);
      const { data, error } = await supabase.rpc('ari_fetch', {
        p_property_id: selectedProperty,
        p_room_type_id: selectedRoom,
        p_start_date: firstDayOfMonth.toISOString().split('T')[0],
        p_end_date: lastDayOfMonth.toISOString().split('T')[0],
      });

      if (error) {
        toast({ variant: 'destructive', title: 'Error fetching calendar data', description: error.message });
        setCalendarData([]);
      } else {
        setCalendarData(data);
      }
      setLoading(false);
    };

    fetchCalendarData();
  }, [selectedProperty, selectedRoom, currentMonth, firstDayOfMonth, lastDayOfMonth]);

  const handleCellEdit = (date, field, value) => {
    setEditingCell({ date, field });
    setEditValue(value);
  };

  const handleSaveEdit = async () => {
    if (!editingCell) return;
    
    const { date, field } = editingCell;
    const { data: baseRatePlan, error: ratePlanError } = await supabase.from('rate_plans').select('id').eq('property_id', selectedProperty).eq('is_base_plan', true).single();
    
    if (ratePlanError || !baseRatePlan) {
        toast({ variant: 'destructive', title: 'Base rate plan not found' });
        return;
    }

    const updatePayload = {
        property_id: selectedProperty,
        room_type_id: selectedRoom,
        rate_plan_id: baseRatePlan.id,
        date: date,
        [field === 'price' ? 'price_numeric' : field]: editValue
    };

    const { error } = await supabase.from('inventory').upsert(updatePayload, { onConflict: 'property_id,room_type_id,rate_plan_id,date' });

    if (error) {
        toast({ variant: 'destructive', title: 'Failed to update', description: error.message });
    } else {
        toast({ title: 'Update successful' });
        setCalendarData(prev => prev.map(d => d.date === date ? { ...d, [field]: editValue } : d));
    }
    setEditingCell(null);
  };

  const renderCell = (dayData, field) => {
    const isEditing = editingCell?.date === dayData.date && editingCell?.field === field;
    const value = dayData[field];

    if (isEditing) {
      return (
        <div className="relative">
          <Input
            type="number"
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSaveEdit()}
            className="h-6 p-1 text-center"
            autoFocus
          />
          <Button size="icon" variant="ghost" className="absolute -right-6 top-1/2 -translate-y-1/2 h-6 w-6" onClick={handleSaveEdit}><Save className="w-3 h-3" /></Button>
          <Button size="icon" variant="ghost" className="absolute -left-6 top-1/2 -translate-y-1/2 h-6 w-6" onClick={() => setEditingCell(null)}><X className="w-3 h-3" /></Button>
        </div>
      );
    }
    return <span onClick={() => handleCellEdit(dayData.date, field, value)}>{value}</span>;
  };

  const daysInMonth = lastDayOfMonth.getDate();
  const startingDayOfWeek = firstDayOfMonth.getDay();
  const monthName = currentMonth.toLocaleString('default', { month: 'long', year: 'numeric' });

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <h1 className="text-4xl font-bold gradient-text mb-8">Rate & Inventory Calendar</h1>

      <div className="glass-effect rounded-2xl p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <div>
            <label className="text-sm font-medium text-gray-700">Property</label>
            <Select value={selectedProperty} onValueChange={setSelectedProperty} disabled={contextLoading}>
              <SelectTrigger>{contextLoading ? 'Loading...' : properties.find(p => p.id === selectedProperty)?.name_en}</SelectTrigger>
              <SelectContent>
                {properties.map(p => <SelectItem key={p.id} value={p.id}>{p.name_en}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700">Room Type</label>
            <Select value={selectedRoom} onValueChange={setSelectedRoom} disabled={!selectedProperty || propertyRooms.length === 0}>
              <SelectTrigger>{!selectedProperty ? 'Select a property' : propertyRooms.length === 0 ? 'No rooms' : propertyRooms.find(r => r.id === selectedRoom)?.name_en}</SelectTrigger>
              <SelectContent>
                {propertyRooms.map(r => <SelectItem key={r.id} value={r.id}>{r.name_en}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center justify-between bg-white/50 p-2 rounded-xl">
            <Button variant="ghost" size="icon" onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1))}><ChevronLeft className="w-5 h-5" /></Button>
            <h2 className="text-lg font-bold text-gray-900 whitespace-nowrap">{monthName}</h2>
            <Button variant="ghost" size="icon" onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1))}><ChevronRight className="w-5 h-5" /></Button>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-96"><Loader2 className="w-8 h-8 animate-spin text-blue-600" /></div>
      ) : !selectedProperty || !selectedRoom ? (
        <div className="text-center py-16 text-gray-500">Please select a property and a room type to view the calendar.</div>
      ) : (
        <div className="overflow-x-auto">
          <div className="grid grid-cols-7 gap-px bg-gray-200 border border-gray-200 min-w-[1200px]">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="text-center font-semibold text-gray-600 py-2 bg-gray-50">{day}</div>
            ))}
            {Array.from({ length: startingDayOfWeek }).map((_, idx) => <div key={`empty-${idx}`} className="bg-gray-100" />)}
            {Array.from({ length: daysInMonth }).map((_, idx) => {
              const day = idx + 1;
              const dateStr = `${currentMonth.getFullYear()}-${String(currentMonth.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
              const dayData = calendarData.find(d => d.date === dateStr);

              if (!dayData) return <div key={day} className="bg-white p-2"><div className="font-bold">{day}</div>...</div>;

              const isSoldOut = dayData.allotment - dayData.sold_count <= 0;

              return (
                <div key={day} className={cn("bg-white p-2 space-y-1 text-xs", { 'bg-red-50': isSoldOut })}>
                  <div className="font-bold text-sm text-gray-800">{day}</div>
                  <div className="flex justify-between items-center"><span>Price</span> <span className="font-semibold text-green-700">€{renderCell(dayData, 'price')}</span></div>
                  <div className="flex justify-between items-center"><span>Avail.</span> <span className="font-semibold">{renderCell(dayData, 'allotment')}</span></div>
                  <div className="flex justify-between items-center"><span>Sold</span> <span className="font-semibold text-red-700">{dayData.sold_count}</span></div>
                  <div className="flex justify-between items-center"><span>MinLOS</span> <span className="font-semibold">{renderCell(dayData, 'min_los')}</span></div>
                  <div className="flex justify-between items-center text-gray-500">
                    <div className="flex gap-1">
                      <Ban className={cn("w-3 h-3", { 'text-red-500': dayData.stop_sell })} title="Stop Sell" />
                      <ArrowRight className={cn("w-3 h-3", { 'text-red-500': dayData.cta })} title="Closed to Arrival" />
                      <ArrowLeft className={cn("w-3 h-3", { 'text-red-500': dayData.ctd })} title="Closed to Departure" />
                    </div>
                    <Lock className="w-3 h-3" title="Derived Rate" />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </motion.div>
  );
};

export default AdminCalendar;
