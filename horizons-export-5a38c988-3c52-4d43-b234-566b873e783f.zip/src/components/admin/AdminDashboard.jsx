import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Users, DollarSign, Calendar } from 'lucide-react';
import { useBookingData } from '@/hooks/useBookingData';
import { useTranslation } from 'react-i18next';

const AdminDashboard = () => {
  const { bookings, customers, properties, loading } = useBookingData();
  const { i18n } = useTranslation();
  const currentLang = i18n.language;

  const confirmedBookings = bookings?.filter(b => b.status === 'confirmed') || [];
  const totalRevenue = confirmedBookings.reduce((sum, b) => sum + (b.total_price || 0), 0);
  const avgBookingValue = confirmedBookings.length > 0 ? totalRevenue / confirmedBookings.length : 0;

  const stats = [
    { 
      label: 'Total Revenue', 
      value: `$${totalRevenue.toFixed(0)}`, 
      icon: DollarSign, 
      color: 'from-green-500 to-emerald-600',
      change: '+12.5%'
    },
    { 
      label: 'Bookings', 
      value: bookings?.length || 0, 
      icon: Calendar, 
      color: 'from-blue-500 to-indigo-600',
      change: '+8.2%'
    },
    { 
      label: 'Customers', 
      value: customers?.length || 0, 
      icon: Users, 
      color: 'from-purple-500 to-pink-600',
      change: '+15.3%'
    },
    { 
      label: 'Avg Booking', 
      value: `$${avgBookingValue.toFixed(0)}`, 
      icon: TrendingUp, 
      color: 'from-orange-500 to-red-600',
      change: '+5.7%'
    },
  ];

  if (loading) {
    return <div>Loading dashboard...</div>;
  }

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold gradient-text mb-8">Dashboard Overview</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="glass-effect rounded-2xl p-6 card-hover"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className={`bg-gradient-to-br ${stat.color} p-3 rounded-xl`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-sm font-semibold text-green-600">{stat.change}</span>
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </motion.div>
            );
          })}
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="glass-effect rounded-2xl p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Recent Bookings</h2>
            <div className="space-y-3">
              {(bookings || []).slice(0, 5).map((booking) => (
                <div key={booking.id} className="flex items-center justify-between p-4 bg-white/50 rounded-xl">
                  <div>
                    <div className="font-semibold text-gray-900">{booking.booking_uid}</div>
                    <div className="text-sm text-gray-600">{booking.check_in} - {booking.check_out}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-blue-600">${booking.total_price}</div>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      booking.status === 'confirmed' ? 'bg-green-100 text-green-700' :
                      booking.status === 'hold' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      {booking.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-effect rounded-2xl p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Properties Overview</h2>
            <div className="space-y-3">
              {(properties || []).map((property) => (
                <div key={property.id} className="p-4 bg-white/50 rounded-xl">
                  <div className="flex items-center gap-3 mb-2">
                    <img
                      alt={property[`name_${currentLang}`] || property.name_en}
                      className="w-16 h-16 object-cover rounded-lg"
                     src="https://images.unsplash.com/photo-1603092981646-b657d5521173" />
                    <div>
                      <div className="font-semibold text-gray-900">{property[`name_${currentLang}`] || property.name_en}</div>
                      <div className="text-sm text-gray-600">{property.city}</div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Rating: {property.stars} ⭐</span>
                    <span className="text-blue-600 font-medium">View Details →</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default AdminDashboard;