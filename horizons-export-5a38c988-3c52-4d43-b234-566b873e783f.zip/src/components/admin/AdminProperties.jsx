import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, MapPin, Star, Edit, Trash2, Image as ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useBookingData } from '@/hooks/useBookingData';
import { toast } from '@/components/ui/use-toast';
import { useTranslation } from 'react-i18next';
import AddPropertyWizard from '@/components/admin/AddPropertyWizard';

const AdminProperties = () => {
  const { properties, loading, refetch } = useBookingData();
  const { i18n } = useTranslation();
  const currentLang = i18n.language;
  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const [editingProperty, setEditingProperty] = useState(null);

  const handleWizardClose = (didSave) => {
    setIsWizardOpen(false);
    setEditingProperty(null);
    if (didSave) {
      refetch();
    }
  };

  const handleAddNew = () => {
    setEditingProperty(null);
    setIsWizardOpen(true);
  };

  const handleEdit = (property) => {
    setEditingProperty(property);
    setIsWizardOpen(true);
  };

  if (loading) {
    return (
      <div className="space-y-6">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="bg-white/10 p-6 rounded-2xl animate-pulse">
            <div className="grid md:grid-cols-3 gap-6">
              <div className="w-full h-64 bg-white/20 rounded-xl"></div>
              <div className="md:col-span-2 space-y-4">
                <div className="h-8 w-3/4 bg-white/20 rounded"></div>
                <div className="h-6 w-1/2 bg-white/20 rounded"></div>
                <div className="h-10 w-full bg-white/20 rounded"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div>
      <AddPropertyWizard 
        isOpen={isWizardOpen} 
        onClose={handleWizardClose} 
        propertyToEdit={editingProperty} 
      />
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl font-bold text-ebony">Properties</h1>
          <Button
            className="bg-champagne-gold text-ebony hover:bg-champagne-gold/90"
            onClick={handleAddNew}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Property
          </Button>
        </div>

        <div className="grid gap-8">
          {(properties || []).map((property, idx) => (
            <motion.div
              key={property.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-ivory border border-champagne-gold/20 rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-shadow duration-300"
            >
              <div className="grid md:grid-cols-12 gap-6 p-6">
                <div className="md:col-span-4">
                  {property.hero_url ? (
                    <img
                      alt={property[`name_${currentLang}`] || property.name_en}
                      className="w-full h-64 object-cover rounded-xl"
                      src={property.hero_url} />
                  ) : (
                    <div className="w-full h-64 bg-gray-200 rounded-xl flex items-center justify-center">
                      <ImageIcon className="w-12 h-12 text-gray-400" />
                    </div>
                  )}
                </div>

                <div className="md:col-span-8">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-2xl font-serif font-bold text-ebony mb-2">{property[`name_${currentLang}`] || property.name_en}</h3>
                      <div className="flex items-center gap-2 text-graphite/80 mb-3">
                        <MapPin className="w-4 h-4" />
                        <span>{property.city}, {property.country}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                       <div className="flex items-center gap-1 bg-champagne-gold/10 px-3 py-1 rounded-full">
                        <Star className="w-4 h-4 fill-champagne-gold text-champagne-gold" />
                        <span className="font-semibold text-ebony">{property.rating || 'N/A'}</span>
                      </div>
                      {property.is_featured && (
                        <span className="px-3 py-1 bg-champagne-gold text-ebony rounded-full text-xs font-bold">FEATURED</span>
                      )}
                    </div>
                  </div>

                  <p className="text-graphite/90 mb-4 text-sm">{property[`description_${currentLang}`] || property.description_en}</p>

                  <div className="flex flex-wrap gap-2 mb-6">
                    {property.amenities?.map(amenity => (
                      <span 
                        key={amenity}
                        className="px-3 py-1 bg-ebony/5 text-ebony rounded-full text-xs capitalize"
                      >
                        {amenity.replace(/_/g, ' ')}
                      </span>
                    ))}
                  </div>

                  <div className="border-t border-champagne-gold/20 pt-4 flex items-center justify-between">
                     <div>
                        <span className="text-sm text-graphite/80">Starting from</span>
                        <p className="text-xl font-bold text-ebony">{new Intl.NumberFormat('en-US', { style: 'currency', currency: property.currency || 'TRY' }).format(property.starting_price)} <span className="text-sm font-normal">/ night</span></p>
                     </div>
                     <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm" onClick={() => handleEdit(property)}>
                            <Edit className="w-4 h-4 mr-2" /> Edit
                        </Button>
                        <Button variant="destructive" size="sm" onClick={() => toast({ title: "🚧 Feature not implemented" })}>
                            <Trash2 className="w-4 h-4 mr-2" /> Delete
                        </Button>
                     </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
};

export default AdminProperties;