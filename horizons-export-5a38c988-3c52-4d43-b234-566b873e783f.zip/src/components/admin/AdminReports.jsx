import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, DollarSign, Percent, Calendar } from 'lucide-react';
import { useBookingData } from '@/hooks/useBookingData';

const AdminReports = () => {
  const { bookings } = useBookingData();

  const confirmedBookings = bookings.filter(b => b.status === 'confirmed');
  const totalRevenue = confirmedBookings.reduce((sum, b) => sum + b.totalPrice, 0);
  const avgDailyRate = confirmedBookings.length > 0 ? totalRevenue / confirmedBookings.length : 0;

  const metrics = [
    { label: 'ADR (Avg Daily Rate)', value: `$${avgDailyRate.toFixed(2)}`, icon: DollarSign, color: 'from-green-500 to-emerald-600' },
    { label: 'Occupancy Rate', value: '78.5%', icon: Percent, color: 'from-blue-500 to-indigo-600' },
    { label: 'RevPAR', value: `$${(avgDailyRate * 0.785).toFixed(2)}`, icon: TrendingUp, color: 'from-purple-500 to-pink-600' },
    { label: 'Total Bookings', value: bookings.length, icon: Calendar, color: 'from-orange-500 to-red-600' },
  ];

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold gradient-text mb-8">Reports & Analytics</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {metrics.map((metric, idx) => {
            const Icon = metric.icon;
            return (
              <motion.div
                key={metric.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="glass-effect rounded-2xl p-6 card-hover"
              >
                <div className={`bg-gradient-to-br ${metric.color} p-3 rounded-xl w-fit mb-4`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-1">{metric.value}</div>
                <div className="text-sm text-gray-600">{metric.label}</div>
              </motion.div>
            );
          })}
        </div>

        <div className="glass-effect rounded-2xl p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Revenue Breakdown</h2>
          <div className="h-64 flex items-center justify-center text-gray-500">
            Chart visualization would go here 📊
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default AdminReports;