import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Search, Filter, Calendar, Users, DollarSign, MoreVertical, Edit, Trash2, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useBookingData } from '@/hooks/useBookingData';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';

const AdminReservations = () => {
  const { bookings, properties, rooms, customers, loading, refetch } = useBookingData();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const filteredBookings = useMemo(() => {
    if (!bookings) return [];
    return bookings.filter(booking => {
      const customer = customers.find(c => c.id === booking.customer_id);
      const searchLower = searchTerm.toLowerCase();
      
      const matchesSearch = (
        (booking.booking_uid && booking.booking_uid.toLowerCase().includes(searchLower)) ||
        (customer && customer.name.toLowerCase().includes(searchLower)) ||
        (customer && customer.email.toLowerCase().includes(searchLower))
      );
      const matchesStatus = statusFilter === 'all' || booking.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [bookings, customers, searchTerm, statusFilter]);

  const handleCancelBooking = async (bookingId) => {
    const { data, error } = await supabase.rpc('hotel_cancel_booking', {
      p_booking_id: bookingId,
      p_reason: 'Cancelled by admin'
    });

    if (error) {
      toast({ variant: 'destructive', title: 'Cancellation Failed', description: error.message });
    } else {
      toast({ title: 'Booking Cancelled', description: `Refund of ${data.refund_amount} processed.` });
      refetch();
    }
  };

  const getPropertyName = (propertyId) => {
    const property = properties.find(p => p.id === propertyId);
    return property ? property.name_en : 'Unknown';
  };

  const getRoomName = (roomId) => {
    const room = rooms.find(r => r.id === roomId);
    return room ? room.name_en : 'Unknown';
  };

  const getCustomerName = (customerId) => {
    const customer = customers.find(c => c.id === customerId);
    return customer ? customer.name : 'Unknown';
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'confirmed': return 'bg-green-100 text-green-700';
      case 'hold': return 'bg-yellow-100 text-yellow-700';
      case 'awaiting_payment': return 'bg-blue-100 text-blue-700';
      case 'cancelled': return 'bg-red-100 text-red-700';
      case 'refunded': return 'bg-gray-100 text-gray-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold gradient-text mb-8">Reservations Management</h1>

        <div className="glass-effect rounded-2xl p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                type="text"
                placeholder="Search by ID, customer name, or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:outline-none transition-colors"
              />
            </div>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-[180px] px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:outline-none transition-colors">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="confirmed">Confirmed</SelectItem>
                <SelectItem value="hold">On Hold</SelectItem>
                <SelectItem value="awaiting_payment">Awaiting Payment</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
                <SelectItem value="refunded">Refunded</SelectItem>
              </SelectContent>
            </Select>

            <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700" onClick={() => toast({ title: "🚧 Feature not implemented" })}>
              <Filter className="w-4 h-4 mr-2" />
              More Filters
            </Button>
          </div>
        </div>

        <div className="glass-effect rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-white/50">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Booking ID</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Customer</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Property & Room</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Dates</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Total</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Status</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan="7" className="text-center py-8">Loading reservations...</td></tr>
                ) : filteredBookings.map((booking, idx) => (
                  <motion.tr
                    key={booking.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    className="border-b border-gray-200 hover:bg-white/50 transition-colors"
                  >
                    <td className="px-6 py-4 font-mono font-semibold text-blue-600">{booking.booking_uid}</td>
                    <td className="px-6 py-4">{getCustomerName(booking.customer_id)}</td>
                    <td className="px-6 py-4">
                      <div>{getPropertyName(booking.property_id)}</div>
                      <div className="text-xs text-gray-500">{getRoomName(booking.room_id)}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 text-sm">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        <span>{booking.check_in} → {booking.check_out}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 font-semibold text-green-600">
                        <DollarSign className="w-4 h-4" />
                        <span>{booking.total_price} {booking.currency}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium capitalize ${getStatusColor(booking.status)}`}>
                        {booking.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => toast({ title: "🚧 Feature not implemented" })}>
                            <Edit className="w-4 h-4 mr-2" /> View/Edit Details
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => toast({ title: "🚧 Feature not implemented" })}>
                            <Mail className="w-4 h-4 mr-2" /> Resend Confirmation
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-red-600" onClick={() => handleCancelBooking(booking.id)}>
                            <Trash2 className="w-4 h-4 mr-2" /> Cancel Booking
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default AdminReservations;