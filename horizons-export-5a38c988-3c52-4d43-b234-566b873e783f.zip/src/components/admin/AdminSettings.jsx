import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { CreditCard, Globe, Bell, Building, Palette, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useBookingData } from '@/hooks/useBookingData';
import { supabase } from '@/lib/customSupabaseClient';

const GeneralSettings = ({ settings, onUpdate, loading }) => (
  <div className="space-y-6">
    <div className="p-6 bg-white/80 rounded-xl shadow-sm">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Business Information</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="businessName">Business Name</Label>
          <Input id="businessName" value={settings.business_name || ''} onChange={(e) => onUpdate('business_name', e.target.value)} disabled={loading} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="contactEmail">Contact Email</Label>
          <Input id="contactEmail" type="email" value={settings.contact_email || ''} onChange={(e) => onUpdate('contact_email', e.target.value)} disabled={loading} />
        </div>
      </div>
    </div>
    <div className="p-6 bg-white/80 rounded-xl shadow-sm">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Brand Customization</h3>
      <div className="flex items-center space-x-4">
        <div className="w-24 h-24 bg-gray-200 rounded-lg flex items-center justify-center">
          {settings.logo_url ? <img src={settings.logo_url} alt="Brand Logo" className="w-full h-full object-contain rounded-lg" /> : <Palette className="w-10 h-10 text-gray-500" />}
        </div>
        <div className="space-y-2">
          <Label>Brand Logo</Label>
          <Button variant="outline" onClick={() => toast({ description: "🚧 Feature not implemented." })} disabled={loading}>Upload Logo</Button>
          <p className="text-xs text-gray-500">Recommended size: 256x256px</p>
        </div>
      </div>
    </div>
  </div>
);

const PaymentSettings = ({ settings, onUpdate, loading }) => (
  <div className="space-y-6">
    <div className="p-6 bg-white/80 rounded-xl shadow-sm">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Stripe Integration</h3>
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-8 bg-white border rounded-md flex items-center justify-center">
            <CreditCard className="w-6 h-6 text-indigo-600" />
          </div>
          <div>
            <p className="font-medium">Stripe</p>
            <p className={`text-sm ${settings.stripe_connected ? 'text-green-600' : 'text-red-600'}`}>{settings.stripe_connected ? 'Connected' : 'Not Connected'}</p>
          </div>
        </div>
        <Button variant="secondary" onClick={() => toast({ description: "🚧 Feature not implemented." })} disabled={loading}>Manage</Button>
      </div>
    </div>
    <div className="p-6 bg-white/80 rounded-xl shadow-sm">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Tax Settings</h3>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Label htmlFor="vatRate">Default VAT Rate (%)</Label>
          <Input id="vatRate" type="number" className="w-24" value={settings.default_vat_pct || ''} onChange={(e) => onUpdate('default_vat_pct', parseFloat(e.target.value))} disabled={loading} />
        </div>
        <div className="flex items-center justify-between">
          <Label htmlFor="cityTax">Enable City Tax</Label>
          <Switch id="cityTax" checked={settings.enable_city_tax || false} onCheckedChange={(checked) => onUpdate('enable_city_tax', checked)} disabled={loading} />
        </div>
      </div>
    </div>
  </div>
);

const LocalizationSettings = ({ settings, onUpdate, loading }) => (
  <div className="space-y-6">
    <div className="p-6 bg-white/80 rounded-xl shadow-sm">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Language & Region</h3>
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Default Language</Label>
            <Select value={settings.default_language || 'en'} onValueChange={(value) => onUpdate('default_language', value)} disabled={loading}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {(settings.supported_languages || ['en', 'tr']).map(lang => <SelectItem key={lang} value={lang}>{lang.toUpperCase()}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Default Currency</Label>
            <Select value={settings.default_currency || 'eur'} onValueChange={(value) => onUpdate('default_currency', value)} disabled={loading}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {(settings.supported_currencies || ['eur', 'try', 'usd']).map(curr => <SelectItem key={curr} value={curr}>{curr.toUpperCase()}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
    </div>
  </div>
);

const NotificationSettings = () => (
  <div className="space-y-6">
    <div className="p-6 bg-white/80 rounded-xl shadow-sm">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Email Templates</h3>
      <p className="text-sm text-gray-600 mb-4">Configure emails sent to customers and staff.</p>
      <div className="space-y-2">
        {['Booking Confirmation', 'Cancellation Notice', 'Pre-stay Reminder'].map(template => (
          <div key={template} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <span className="text-gray-700">{template}</span>
            <Button variant="ghost" size="sm" onClick={() => toast({ description: "🚧 Feature not implemented." })}>Edit Template →</Button>
          </div>
        ))}
      </div>
    </div>
  </div>
);

const AdminSettings = () => {
  const { appSettings, loading: dataLoading, refetch } = useBookingData();
  const [localSettings, setLocalSettings] = useState({});
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (appSettings) {
      setLocalSettings(appSettings);
    }
  }, [appSettings]);

  const handleUpdate = (key, value) => {
    setLocalSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleSaveChanges = async () => {
    setIsSaving(true);
    const { error } = await supabase
      .from('app_settings')
      .update({ ...localSettings, updated_at: new Date().toISOString() })
      .eq('id', 1);

    if (error) {
      toast({ variant: 'destructive', title: 'Error saving settings', description: error.message });
    } else {
      toast({ title: 'Settings Saved!', description: 'Your new configurations have been applied.' });
      refetch();
    }
    setIsSaving(false);
  };

  const isLoading = dataLoading || isSaving;

  const tabs = [
    { value: 'general', label: 'General', icon: Building, component: <GeneralSettings settings={localSettings} onUpdate={handleUpdate} loading={isLoading} /> },
    { value: 'payments', label: 'Payments', icon: CreditCard, component: <PaymentSettings settings={localSettings} onUpdate={handleUpdate} loading={isLoading} /> },
    { value: 'localization', label: 'Localization', icon: Globe, component: <LocalizationSettings settings={localSettings} onUpdate={handleUpdate} loading={isLoading} /> },
    { value: 'notifications', label: 'Notifications', icon: Bell, component: <NotificationSettings /> },
  ];

  if (dataLoading && !appSettings) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h1 className="text-4xl font-bold gradient-text mb-8">Settings</h1>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-white/60 backdrop-blur-sm p-2 h-auto rounded-xl shadow-inner-sm">
          {tabs.map(({ value, label, icon: Icon }) => (
            <TabsTrigger key={value} value={value} className="flex items-center gap-2 text-gray-600 data-[state=active]:bg-white data-[state=active]:text-blue-600 data-[state=active]:shadow-md rounded-lg">
              <Icon className="w-5 h-5" />
              <span className="hidden md:inline">{label}</span>
            </TabsTrigger>
          ))}
        </TabsList>
        
        <div className="mt-6">
          {tabs.map(({ value, component }) => (
            <TabsContent key={value} value={value}>
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                {component}
              </motion.div>
            </TabsContent>
          ))}
        </div>
      </Tabs>
      
      <div className="mt-8 flex justify-end">
        <Button 
          className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white"
          onClick={handleSaveChanges}
          disabled={isLoading}
        >
          {isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
          Save Changes
        </Button>
      </div>
    </motion.div>
  );
};

export default AdminSettings;