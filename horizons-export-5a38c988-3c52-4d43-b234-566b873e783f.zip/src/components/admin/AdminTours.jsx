import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Loader2, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useBookingData } from '@/hooks/useBookingData';
import AddTourWizard from '@/components/admin/AddTourWizard';

const AdminTours = () => {
  const [view, setView] = useState('list'); // 'list' or 'wizard'
  const { tours, loading, error, refetch } = useBookingData();

  const handleAddTour = () => {
    setView('wizard');
  };

  const handleWizardClose = (tourAdded) => {
    setView('list');
    if (tourAdded) {
      refetch();
    }
  };

  if (view === 'wizard') {
    return <AddTourWizard onClose={handleWizardClose} />;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-4xl font-bold text-ebony">Tours</h1>
        <Button
          className="bg-champagne-gold text-ebony hover:bg-champagne-gold/90"
          onClick={handleAddTour}
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Tour
        </Button>
      </div>

      {loading && (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-champagne-gold" />
        </div>
      )}

      {error && (
        <div className="flex flex-col items-center justify-center h-64 bg-red-50 border border-red-200 rounded-lg p-4">
          <AlertTriangle className="w-12 h-12 text-red-500 mb-4" />
          <h3 className="text-xl font-semibold text-red-700">Failed to load tours</h3>
          <p className="text-red-600">{error}</p>
          <Button variant="outline" className="mt-4" onClick={refetch}>
            Try Again
          </Button>
        </div>
      )}

      {!loading && !error && tours.length === 0 && (
        <div className="text-center py-16 border-2 border-dashed border-gray-300 rounded-lg">
          <h2 className="text-xl font-semibold text-gray-700">No Tours Found</h2>
          <p className="text-gray-500 mt-2">Get started by adding your first tour.</p>
          <Button className="mt-4" onClick={handleAddTour}>
            <Plus className="w-4 h-4 mr-2" />
            Add Your First Tour
          </Button>
        </div>
      )}

      {!loading && !error && tours.length > 0 && (
        <div className="bg-white shadow-md rounded-lg overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tour Name</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Duration</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th scope="col" className="relative px-6 py-3">
                  <span className="sr-only">Edit</span>
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {tours.map((tour) => (
                <tr key={tour.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{tour.name_en}</div>
                    <div className="text-sm text-gray-500">{tour.city}, {tour.country}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{tour.category}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{tour.duration_minutes} min</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      tour.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {tour.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <a href="#" className="text-indigo-600 hover:text-indigo-900">Edit</a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </motion.div>
  );
};

export default AdminTours;