import React from 'react';
import { motion } from 'framer-motion';
import { Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const CallCenterCRM = () => {
  const pipelines = [
    { id: 1, name: 'New Leads', count: 12, color: 'from-blue-500 to-indigo-600' },
    { id: 2, name: 'Contacted', count: 8, color: 'from-purple-500 to-pink-600' },
    { id: 3, name: 'Quoted', count: 5, color: 'from-orange-500 to-red-600' },
    { id: 4, name: 'Converted', count: 3, color: 'from-green-500 to-emerald-600' },
  ];

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl font-bold gradient-text">CRM Pipeline</h1>
          <Button 
            className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
            onClick={() => toast({
              title: "Add Lead",
              description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
            })}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Lead
          </Button>
        </div>

        <div className="grid md:grid-cols-4 gap-6">
          {pipelines.map((pipeline, idx) => (
            <motion.div
              key={pipeline.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="glass-effect rounded-2xl p-6"
            >
              <div className={`bg-gradient-to-br ${pipeline.color} p-3 rounded-xl w-fit mb-4`}>
                <span className="text-white font-bold text-xl">{pipeline.count}</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">{pipeline.name}</h3>
              
              <div className="space-y-2">
                {Array.from({ length: Math.min(pipeline.count, 3) }).map((_, i) => (
                  <div key={i} className="p-3 bg-white/50 rounded-lg">
                    <div className="font-semibold text-sm text-gray-900">Lead #{i + 1}</div>
                    <div className="text-xs text-gray-600">Contact info here</div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
};

export default CallCenterCRM;