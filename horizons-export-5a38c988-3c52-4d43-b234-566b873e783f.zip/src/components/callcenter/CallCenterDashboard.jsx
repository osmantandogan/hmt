import React from 'react';
import { motion } from 'framer-motion';
import { Phone, Clock, CheckCircle, XCircle } from 'lucide-react';
import { useBookingData } from '@/hooks/useBookingData';

const CallCenterDashboard = () => {
  const { bookings } = useBookingData();

  const todayBookings = bookings.filter(b => {
    const today = new Date().toISOString().split('T')[0];
    return b.createdAt === today;
  });

  const stats = [
    { label: 'Calls Today', value: '24', icon: Phone, color: 'from-emerald-500 to-teal-600' },
    { label: 'Avg Call Time', value: '8m 32s', icon: Clock, color: 'from-blue-500 to-indigo-600' },
    { label: 'Bookings Created', value: todayBookings.length, icon: CheckCircle, color: 'from-green-500 to-emerald-600' },
    { label: 'Cancelled', value: '2', icon: XCircle, color: 'from-red-500 to-pink-600' },
  ];

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold gradient-text mb-8">Call Center Dashboard</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="glass-effect rounded-2xl p-6 card-hover"
              >
                <div className={`bg-gradient-to-br ${stat.color} p-3 rounded-xl w-fit mb-4`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </motion.div>
            );
          })}
        </div>

        <div className="glass-effect rounded-2xl p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Recent Activity</h2>
          <div className="space-y-3">
            {bookings.slice(0, 5).map((booking) => (
              <div key={booking.id} className="flex items-center justify-between p-4 bg-white/50 rounded-xl">
                <div>
                  <div className="font-semibold text-gray-900">{booking.id}</div>
                  <div className="text-sm text-gray-600">Created: {booking.createdAt}</div>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  booking.status === 'confirmed' ? 'bg-green-100 text-green-700' :
                  booking.status === 'hold' ? 'bg-yellow-100 text-yellow-700' :
                  'bg-red-100 text-red-700'
                }`}>
                  {booking.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default CallCenterDashboard;