import React from 'react';
import { motion } from 'framer-motion';
import { LayoutDashboard, Plus, Users, LogOut } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

const CallCenterSidebar = ({ currentSection, onSectionChange, onViewChange }) => {
  const { logout } = useAuth();

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'new-booking', label: 'New Booking', icon: Plus },
    { id: 'crm', label: 'CRM Pipeline', icon: Users },
  ];

  const handleLogout = () => {
    logout();
    onViewChange('public');
  };

  return (
    <motion.div 
      className="fixed left-0 top-0 h-screen w-64 glass-effect border-r border-white/20 p-6"
      initial={{ x: -100, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="mb-8">
        <h1 className="text-2xl font-bold gradient-text">Call Center</h1>
        <p className="text-sm text-gray-600">Agent Portal</p>
      </div>

      <nav className="space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentSection === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onSectionChange(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 ${
                isActive 
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg' 
                  : 'text-gray-700 hover:bg-white/50'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="absolute bottom-6 left-6 right-6">
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-600 hover:bg-red-50 transition-all duration-300"
        >
          <LogOut className="w-5 h-5" />
          <span className="font-medium">Logout</span>
        </button>
      </div>
    </motion.div>
  );
};

export default CallCenterSidebar;