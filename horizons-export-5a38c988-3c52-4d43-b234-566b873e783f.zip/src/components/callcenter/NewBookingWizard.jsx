import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Calendar, Users, DollarSign, Link as LinkIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useBookingData } from '@/hooks/useBookingData';
import { toast } from '@/components/ui/use-toast';

const NewBookingWizard = () => {
  const { properties, rooms, addBooking, addCustomer } = useBookingData();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    propertyId: '',
    roomId: '',
    checkIn: '',
    checkOut: '',
    guests: 2,
    customerName: '',
    customerEmail: '',
    customerPhone: '',
    priceOverride: '',
    overrideReason: '',
  });

  const handleSubmit = () => {
    if (!formData.propertyId || !formData.roomId || !formData.checkIn || !formData.checkOut) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    const customer = addCustomer({
      name: formData.customerName,
      email: formData.customerEmail,
      phone: formData.customerPhone,
      country: 'Turkey',
    });

    const room = rooms.find(r => r.id === formData.roomId);
    const nights = Math.ceil((new Date(formData.checkOut) - new Date(formData.checkIn)) / (1000 * 60 * 60 * 24));
    const totalPrice = formData.priceOverride ? parseFloat(formData.priceOverride) : room.basePrice * nights;

    const booking = addBooking({
      propertyId: formData.propertyId,
      roomId: formData.roomId,
      customerId: customer.id,
      checkIn: formData.checkIn,
      checkOut: formData.checkOut,
      guests: formData.guests,
      status: 'hold',
      totalPrice: totalPrice,
      currency: 'USD',
    });

    toast({
      title: "Booking Created! 🎉",
      description: `Booking ${booking.id} created and placed on hold`,
    });

    setStep(1);
    setFormData({
      propertyId: '',
      roomId: '',
      checkIn: '',
      checkOut: '',
      guests: 2,
      customerName: '',
      customerEmail: '',
      customerPhone: '',
      priceOverride: '',
      overrideReason: '',
    });
  };

  const selectedProperty = properties.find(p => p.id === formData.propertyId);
  const availableRooms = rooms.filter(r => r.propertyId === formData.propertyId);

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold gradient-text mb-8">New Booking Wizard</h1>

        <div className="glass-effect rounded-2xl p-8">
          <div className="flex items-center justify-between mb-8">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                  step >= s 
                    ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white' 
                    : 'bg-gray-200 text-gray-500'
                }`}>
                  {s}
                </div>
                {s < 3 && <div className={`w-24 h-1 mx-2 ${step > s ? 'bg-emerald-600' : 'bg-gray-200'}`} />}
              </div>
            ))}
          </div>

          {step === 1 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Select Property & Room</h2>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Property</label>
                <select
                  value={formData.propertyId}
                  onChange={(e) => setFormData({ ...formData, propertyId: e.target.value, roomId: '' })}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-emerald-500 focus:outline-none transition-colors"
                >
                  <option value="">Select a property</option>
                  {properties.map(property => (
                    <option key={property.id} value={property.id}>{property.name}</option>
                  ))}
                </select>
              </div>

              {formData.propertyId && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Room Type</label>
                  <div className="grid gap-3">
                    {availableRooms.map(room => (
                      <div
                        key={room.id}
                        onClick={() => setFormData({ ...formData, roomId: room.id })}
                        className={`p-4 rounded-xl cursor-pointer transition-all ${
                          formData.roomId === room.id
                            ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white'
                            : 'bg-white/50 hover:bg-white/80'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-semibold">{room.name}</div>
                            <div className="text-sm opacity-75">Up to {room.capacity} guests</div>
                          </div>
                          <div className="text-xl font-bold">${room.basePrice}/night</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <Button 
                onClick={() => setStep(2)}
                disabled={!formData.roomId}
                className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
              >
                Next Step →
              </Button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Booking Details</h2>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Check-in Date</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="date"
                      value={formData.checkIn}
                      onChange={(e) => setFormData({ ...formData, checkIn: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-emerald-500 focus:outline-none transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Check-out Date</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="date"
                      value={formData.checkOut}
                      onChange={(e) => setFormData({ ...formData, checkOut: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-emerald-500 focus:outline-none transition-colors"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Number of Guests</label>
                <div className="relative">
                  <Users className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <select
                    value={formData.guests}
                    onChange={(e) => setFormData({ ...formData, guests: Number(e.target.value) })}
                    className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-emerald-500 focus:outline-none transition-colors"
                  >
                    {[1, 2, 3, 4, 5, 6].map(num => (
                      <option key={num} value={num}>{num} Guest{num > 1 ? 's' : ''}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex gap-3">
                <Button 
                  onClick={() => setStep(1)}
                  variant="outline"
                  className="flex-1"
                >
                  ← Back
                </Button>
                <Button 
                  onClick={() => setStep(3)}
                  className="flex-1 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
                >
                  Next Step →
                </Button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Customer & Payment</h2>
              
              <div className="grid gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Customer Name</label>
                  <input
                    type="text"
                    value={formData.customerName}
                    onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-emerald-500 focus:outline-none transition-colors"
                    placeholder="John Doe"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                  <input
                    type="email"
                    value={formData.customerEmail}
                    onChange={(e) => setFormData({ ...formData, customerEmail: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-emerald-500 focus:outline-none transition-colors"
                    placeholder="john@example.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                  <input
                    type="tel"
                    value={formData.customerPhone}
                    onChange={(e) => setFormData({ ...formData, customerPhone: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-emerald-500 focus:outline-none transition-colors"
                    placeholder="+1 555 123 4567"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Price Override (Optional)</label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="number"
                      value={formData.priceOverride}
                      onChange={(e) => setFormData({ ...formData, priceOverride: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-emerald-500 focus:outline-none transition-colors"
                      placeholder="Leave empty for standard rate"
                    />
                  </div>
                </div>

                {formData.priceOverride && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Override Reason</label>
                    <textarea
                      value={formData.overrideReason}
                      onChange={(e) => setFormData({ ...formData, overrideReason: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-emerald-500 focus:outline-none transition-colors"
                      rows="3"
                      placeholder="Reason for price override..."
                    />
                  </div>
                )}
              </div>

              <div className="flex gap-3">
                <Button 
                  onClick={() => setStep(2)}
                  variant="outline"
                  className="flex-1"
                >
                  ← Back
                </Button>
                <Button 
                  onClick={handleSubmit}
                  className="flex-1 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
                >
                  Create Booking
                </Button>
              </div>

              <Button 
                variant="outline"
                className="w-full"
                onClick={() => toast({
                  title: "Payment Link",
                  description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
                })}
              >
                <LinkIcon className="w-4 h-4 mr-2" />
                Generate Payment Link
              </Button>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default NewBookingWizard;