import React, { useState } from 'react';
import { motion } from 'framer-motion';
import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminDashboard from '@/components/admin/AdminDashboard';
import AdminReservations from '@/components/admin/AdminReservations';
import AdminProperties from '@/components/admin/AdminProperties';
import AdminCalendar from '@/components/admin/AdminCalendar';
import AdminCustomers from '@/components/admin/AdminCustomers';
import AdminReports from '@/components/admin/AdminReports';
import AdminSettings from '@/components/admin/AdminSettings';
import AdminStaff from '@/components/admin/AdminStaff';
import AdminTours from '@/components/admin/AdminTours';

const AdminLayout = ({ onViewChange }) => {
  const [currentSection, setCurrentSection] = useState('dashboard');

  const renderSection = () => {
    switch (currentSection) {
      case 'dashboard':
        return <AdminDashboard />;
      case 'reservations':
        return <AdminReservations />;
      case 'properties':
        return <AdminProperties />;
      case 'tours':
        return <AdminTours />;
      case 'calendar':
        return <AdminCalendar />;
      case 'customers':
        return <AdminCustomers />;
      case 'staff':
        return <AdminStaff />;
      case 'reports':
        return <AdminReports />;
      case 'settings':
        return <AdminSettings />;
      default:
        return <AdminDashboard />;
    }
  };

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      <AdminSidebar 
        currentSection={currentSection}
        onSectionChange={setCurrentSection}
        onViewChange={onViewChange}
      />
      
      <motion.div 
        className="flex-1 p-8 ml-64"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.3 }}
      >
        {renderSection()}
      </motion.div>
    </div>
  );
};

export default AdminLayout;