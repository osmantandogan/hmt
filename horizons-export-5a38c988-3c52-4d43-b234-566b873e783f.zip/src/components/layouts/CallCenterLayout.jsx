import React, { useState } from 'react';
import { motion } from 'framer-motion';
import CallCenterSidebar from '@/components/callcenter/CallCenterSidebar';
import NewBookingWizard from '@/components/callcenter/NewBookingWizard';
import CallCenterDashboard from '@/components/callcenter/CallCenterDashboard';
import CallCenterCRM from '@/components/callcenter/CallCenterCRM';

const CallCenterLayout = ({ onViewChange }) => {
  const [currentSection, setCurrentSection] = useState('dashboard');

  const renderSection = () => {
    switch (currentSection) {
      case 'dashboard':
        return <CallCenterDashboard />;
      case 'new-booking':
        return <NewBookingWizard />;
      case 'crm':
        return <CallCenterCRM />;
      default:
        return <CallCenterDashboard />;
    }
  };

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50">
      <CallCenterSidebar 
        currentSection={currentSection}
        onSectionChange={setCurrentSection}
        onViewChange={onViewChange}
      />
      
      <motion.div 
        className="flex-1 p-8 ml-64"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.3 }}
      >
        {renderSection()}
      </motion.div>
    </div>
  );
};

export default CallCenterLayout;