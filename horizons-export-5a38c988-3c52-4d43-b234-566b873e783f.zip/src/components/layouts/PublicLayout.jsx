
import React, { useState, createContext, useContext } from 'react';
import { AnimatePresence } from 'framer-motion';
import PublicHeader from '@/components/public/PublicHeader';
import PublicFooter from '@/components/public/PublicFooter';

const CurrencyContext = createContext();
export const useCurrency = () => useContext(CurrencyContext);

const PublicLayout = ({ children }) => {
  const [currency, setCurrency] = useState('TRY');
  const exchangeRate = 35.0; // Dummy rate

  const contextValue = { currency, setCurrency, exchangeRate };

  return (
    <CurrencyContext.Provider value={contextValue}>
      <div className="min-h-screen flex flex-col bg-ivory text-graphite">
        <PublicHeader />
        <main className="flex-grow">
          <AnimatePresence mode="wait">
            {children}
          </AnimatePresence>
        </main>
        <PublicFooter />
      </div>
    </CurrencyContext.Provider>
  );
};

export default PublicLayout;
