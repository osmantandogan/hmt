
import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Calendar, Users, Search, Hotel, Building } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTranslation } from 'react-i18next';
import { toast } from '@/components/ui/use-toast';
import { useBookingData } from '@/hooks/useBookingData';
import { Input } from '@/components/ui/input';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

const BookingSearchOverlay = () => {
  const { t, i18n } = useTranslation();
  const { properties, loading: propertiesLoading } = useBookingData();
  const [destination, setDestination] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [isSuggestionsOpen, setIsSuggestionsOpen] = useState(false);
  const [date, setDate] = useState({ from: undefined, to: undefined });
  const [guests, setGuests] = useState(2);
  const searchRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setIsSuggestionsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [searchRef]);

  const handleDestinationChange = (e) => {
    const value = e.target.value;
    setDestination(value);

    if (value.length > 1) {
      const uniqueCities = [...new Set(properties.map(p => p.city).filter(Boolean))];
      
      const citySuggestions = uniqueCities
        .filter(city => city.toLowerCase().includes(value.toLowerCase()))
        .map(city => ({ type: 'city', name: city }));

      const hotelSuggestions = properties
        .filter(p => (p[`name_${i18n.language}`] || p.name_en).toLowerCase().includes(value.toLowerCase()))
        .map(p => ({ type: 'hotel', name: p[`name_${i18n.language}`] || p.name_en, city: p.city }));

      setSuggestions([...citySuggestions, ...hotelSuggestions]);
      setIsSuggestionsOpen(true);
    } else {
      setSuggestions([]);
      setIsSuggestionsOpen(false);
    }
  };

  const handleSuggestionClick = (suggestion) => {
    setDestination(suggestion.name);
    setIsSuggestionsOpen(false);
  };

  const handleSearch = () => {
    toast({
      title: "🚧 Feature Not Implemented",
      description: "Search functionality will be implemented in a future step.",
    });
  };

  return (
    <motion.div
      className="w-full max-w-5xl bg-ivory/90 backdrop-blur-md rounded-lg p-6 shadow-2xl"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay: 0.4 }}
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 items-center">
        <div className="relative lg:col-span-2" ref={searchRef}>
          <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-graphite-secondary" />
          <Input
            type="text"
            placeholder={t('search_destination')}
            value={destination}
            onChange={handleDestinationChange}
            onFocus={() => destination.length > 1 && setIsSuggestionsOpen(true)}
            className="w-full bg-transparent pl-10 pr-3 py-3 text-graphite placeholder:text-graphite-secondary focus:outline-none h-auto"
          />
          {isSuggestionsOpen && suggestions.length > 0 && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="absolute top-full left-0 mt-2 w-full bg-white rounded-lg shadow-lg z-50 max-h-60 overflow-y-auto"
            >
              <ul>
                {suggestions.map((s, index) => (
                  <li 
                    key={index} 
                    onClick={() => handleSuggestionClick(s)}
                    className="px-4 py-3 hover:bg-gray-100 cursor-pointer flex items-center"
                  >
                    {s.type === 'city' ? <Building className="w-4 h-4 mr-3 text-gray-500" /> : <Hotel className="w-4 h-4 mr-3 text-gray-500" />}
                    <div>
                      <span className="font-medium text-gray-800">{s.name}</span>
                      {s.type === 'hotel' && <span className="text-sm text-gray-500 ml-2">{s.city}</span>}
                    </div>
                  </li>
                ))}
              </ul>
            </motion.div>
          )}
        </div>
        
        <div className="relative md:border-l border-champagne-gold/30 md:px-4">
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant={"ghost"}
                className={cn(
                  "w-full justify-start text-left font-normal h-auto py-3 bg-transparent hover:bg-transparent",
                  !date && "text-muted-foreground"
                )}
              >
                <Calendar className="mr-2 h-5 w-5 text-graphite-secondary" />
                {date?.from ? (
                  date.to ? (
                    <>
                      {format(date.from, "LLL dd, y")} - {format(date.to, "LLL dd, y")}
                    </>
                  ) : (
                    format(date.from, "LLL dd, y")
                  )
                ) : (
                  <span className="text-graphite-secondary">{t('search_checkin')} - {t('search_checkout')}</span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <CalendarComponent
                initialFocus
                mode="range"
                defaultMonth={date?.from}
                selected={date}
                onSelect={setDate}
                numberOfMonths={2}
              />
            </PopoverContent>
          </Popover>
        </div>

        <div className="relative md:border-l border-champagne-gold/30 md:px-4">
          <Users className="absolute left-3 md:left-7 top-1/2 -translate-y-1/2 w-5 h-5 text-graphite-secondary" />
          <select
            value={guests}
            onChange={(e) => setGuests(Number(e.target.value))}
            className="w-full bg-transparent pl-10 md:pl-14 pr-3 py-3 text-graphite placeholder:text-graphite-secondary focus:outline-none appearance-none"
          >
            {[1, 2, 3, 4, 5, 6].map(num => (
              <option key={num} value={num} className="text-graphite">{num} {t('search_guests')}{num > 1 ? 's' : ''}</option>
            ))}
          </select>
        </div>
        <Button
          onClick={handleSearch}
          className="w-full bg-champagne-gold text-ebony hover:bg-champagne-gold/90 rounded-md py-6 text-base lg:col-span-1"
        >
          <Search className="w-5 h-5 mr-2" />
          {t('search_cta')}
        </Button>
      </div>
    </motion.div>
  );
};

export default BookingSearchOverlay;
