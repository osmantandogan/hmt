import React from 'react';
import { Phone } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const CallCenterBanner = () => {
  const { t } = useTranslation();

  return (
    <section className="bg-graphite text-ivory">
      <div className="container mx-auto px-4 py-12 text-center">
        <Phone className="w-8 h-8 text-champagne-gold mx-auto mb-4" />
        <h3 className="text-2xl font-serif mb-2">{t('call_center_title')}</h3>
        <a href="tel:+905551234567" className="text-3xl font-bold hover:text-champagne-gold transition-colors">
          +90 555 123 45 67
        </a>
      </div>
    </section>
  );
};

export default CallCenterBanner;