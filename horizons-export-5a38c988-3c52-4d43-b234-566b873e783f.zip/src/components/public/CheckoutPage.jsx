
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { CreditCard, User, Mail, Phone, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/components/ui/use-toast';
import { useBookingData } from '@/hooks/useBookingData';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const CheckoutPage = ({ bookingData, onComplete, onBack }) => {
  const { user } = useAuth();
  const { refetch } = useBookingData();
  const { t, i18n } = useTranslation();
  const [formData, setFormData] = useState({
    name: user?.user_metadata?.full_name || '',
    email: user?.email || '',
    phone: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const calculateNights = () => {
    const checkIn = new Date(bookingData.searchParams.checkIn);
    const checkOut = new Date(bookingData.searchParams.checkOut);
    return Math.ceil((checkOut - checkIn) / (1000 * 60 * 60 * 24));
  };

  const nights = calculateNights();
  const total = bookingData.room.total_price;
  const subtotal = total / 1.1; // Assuming 10% tax for display
  const tax = total - subtotal;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    if (!formData.name || !formData.email || !formData.phone) {
      toast({
        title: t('error'),
        description: t('fill_all_fields'),
        variant: "destructive",
      });
      setIsSubmitting(false);
      return;
    }

    try {
      let customerId;
      const { data: existingCustomer, error: customerError } = await supabase
        .from('customers')
        .select('id')
        .eq('email', formData.email)
        .single();

      if (existingCustomer) {
        customerId = existingCustomer.id;
      } else {
        const { data: newCustomer, error: newCustomerError } = await supabase
          .from('customers')
          .insert({ name: formData.name, email: formData.email, phone: formData.phone, user_id: user?.id })
          .select()
          .single();
        if (newCustomerError) throw newCustomerError;
        customerId = newCustomer.id;
      }

      const { data: booking, error: bookingError } = await supabase
        .from('bookings')
        .insert({
          property_id: bookingData.room.property.id,
          room_id: bookingData.room.id,
          customer_id: customerId,
          check_in: bookingData.searchParams.checkIn,
          check_out: bookingData.searchParams.checkOut,
          guests: bookingData.searchParams.guests,
          status: 'confirmed',
          total_price: total,
          currency: bookingData.room.currency,
          booking_uid: `B-${Date.now()}`
        })
        .select()
        .single();

      if (bookingError) throw bookingError;

      toast({
        title: t('booking_confirmed_title'),
        description: t('booking_confirmed_desc'),
      });

      await refetch();
      onComplete({
        booking,
        customer: { name: formData.name, email: formData.email, phone: formData.phone },
        room: bookingData.room,
        property: bookingData.room.property,
      });

    } catch (error) {
      console.error("Booking failed:", error);
      toast({
        title: t('booking_failed_title'),
        description: error.message || t('booking_failed_desc'),
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const roomName = bookingData.room[`name_${i18n.language}`] || bookingData.room.name_en;
  const propertyName = bookingData.room.property[`name_${i18n.language}`] || bookingData.room.property.name_en;
  const heroImage = (bookingData.room.property.gallery?.find(m => m.room_type_id === bookingData.room.id))?.url || 'https://images.unsplash.com/photo-1595526114035-0d45ed16433d?auto=format&fit=crop&w=1200&q=80';

  return (
    <div className="container mx-auto px-4 py-12">
      <Button 
        variant="ghost" 
        onClick={onBack}
        className="mb-6 text-brand-green-dark hover:text-brand-green-light"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        {t('back_to_room_details')}
      </Button>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-serif text-graphite mb-8">{t('complete_your_booking')}</h1>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-8 shadow-lg">
              <h2 className="text-2xl font-bold text-graphite mb-6">{t('guest_information')}</h2>
              
              <div className="grid gap-6 mb-8">
                <div>
                  <label className="block text-sm font-medium text-graphite-secondary mb-2">
                    {t('full_name')} *
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-brand-green-light focus:outline-none transition-colors h-auto"
                      placeholder={t('full_name_placeholder')}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-graphite-secondary mb-2">
                    {t('email_address')} *
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-brand-green-light focus:outline-none transition-colors h-auto"
                      placeholder={t('email_placeholder')}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-graphite-secondary mb-2">
                    {t('phone_number')} *
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-brand-green-light focus:outline-none transition-colors h-auto"
                      placeholder={t('phone_placeholder')}
                    />
                  </div>
                </div>
              </div>

              <h2 className="text-2xl font-bold text-graphite mb-6">{t('payment_information')}</h2>
              
              <div className="grid gap-6 mb-8">
                <div>
                  <label className="block text-sm font-medium text-graphite-secondary mb-2">
                    {t('card_number')}
                  </label>
                  <div className="relative">
                    <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                      type="text"
                      value={formData.cardNumber}
                      onChange={(e) => setFormData({ ...formData, cardNumber: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-brand-green-light focus:outline-none transition-colors h-auto"
                      placeholder="1234 5678 9012 3456"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-graphite-secondary mb-2">
                      {t('expiry_date')}
                    </label>
                    <Input
                      type="text"
                      value={formData.expiryDate}
                      onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-brand-green-light focus:outline-none transition-colors h-auto"
                      placeholder="MM/YY"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-graphite-secondary mb-2">
                      CVV
                    </label>
                    <Input
                      type="text"
                      value={formData.cvv}
                      onChange={(e) => setFormData({ ...formData, cvv: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-brand-green-light focus:outline-none transition-colors h-auto"
                      placeholder="123"
                    />
                  </div>
                </div>
              </div>

              <Button 
                type="submit"
                disabled={isSubmitting}
                className="w-full py-6 text-lg bg-champagne-gold text-ebony hover:bg-champagne-gold/90 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                {isSubmitting ? t('processing') : `${t('complete_booking')} - ${new Intl.NumberFormat(i18n.language === 'tr' ? 'tr-TR' : 'en-US', { style: 'currency', currency: bookingData.room.currency, minimumFractionDigits: 0 }).format(total)}`}
              </Button>
            </form>
          </div>

          <div className="md:col-span-1">
            <div className="bg-white rounded-2xl p-6 sticky top-24 shadow-lg">
              <h3 className="text-xl font-bold text-graphite mb-4">{t('booking_summary')}</h3>
              
              <img 
                src={heroImage}
                alt={roomName}
                className="w-full h-48 object-cover rounded-xl mb-4"
              />

              <div className="space-y-3 mb-6">
                <div>
                  <div className="font-semibold text-graphite">{roomName}</div>
                  <div className="text-sm text-graphite-secondary">{propertyName}</div>
                </div>
                
                <div className="border-t pt-3">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-graphite-secondary">{t('checkin')}</span>
                    <span className="font-medium">{bookingData.searchParams.checkIn}</span>
                  </div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-graphite-secondary">{t('checkout')}</span>
                    <span className="font-medium">{bookingData.searchParams.checkOut}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-graphite-secondary">{t('guests')}</span>
                    <span className="font-medium">{bookingData.searchParams.guests}</span>
                  </div>
                </div>

                <div className="border-t pt-3">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-graphite-secondary">{t('subtotal')}</span>
                    <span className="font-medium">{new Intl.NumberFormat(i18n.language === 'tr' ? 'tr-TR' : 'en-US', { style: 'currency', currency: bookingData.room.currency, minimumFractionDigits: 0 }).format(subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-graphite-secondary">{t('taxes_and_fees')}</span>
                    <span className="font-medium">{new Intl.NumberFormat(i18n.language === 'tr' ? 'tr-TR' : 'en-US', { style: 'currency', currency: bookingData.room.currency, minimumFractionDigits: 0 }).format(tax)}</span>
                  </div>
                </div>

                <div className="border-t pt-3">
                  <div className="flex justify-between">
                    <span className="font-bold text-graphite">{t('total')}</span>
                    <span className="font-bold text-2xl text-brand-green-dark">{new Intl.NumberFormat(i18n.language === 'tr' ? 'tr-TR' : 'en-US', { style: 'currency', currency: bookingData.room.currency, minimumFractionDigits: 0 }).format(total)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default CheckoutPage;
