
import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Calendar, MapPin, Users, Mail, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTranslation } from 'react-i18next';

const ConfirmationPage = ({ confirmation, onBackToSearch }) => {
  const { t, i18n } = useTranslation();
  const roomName = confirmation.room[`name_${i18n.language}`] || confirmation.room.name_en;
  const propertyName = confirmation.property[`name_${i18n.language}`] || confirmation.property.name_en;

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="max-w-3xl mx-auto"
      >
        <div className="bg-white rounded-2xl p-8 text-center shadow-2xl">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            className="inline-block mb-6"
          >
            <CheckCircle className="w-24 h-24 text-brand-green-dark" />
          </motion.div>

          <h1 className="text-4xl font-serif text-graphite mb-4">
            {t('booking_confirmed_title')} 🎉
          </h1>
          <p className="text-xl text-graphite-secondary mb-8">
            {t('booking_confirmed_desc')}
          </p>

          <div className="bg-ivory/60 rounded-xl p-6 mb-8 text-left">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-graphite">{t('booking_details')}</h2>
              <span className="text-sm font-mono bg-white px-3 py-1 rounded-full">
                {confirmation.booking.booking_uid}
              </span>
            </div>

            <div className="grid gap-4">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-brand-green-dark mt-1" />
                <div>
                  <div className="font-semibold text-graphite">{roomName}</div>
                  <div className="text-graphite-secondary">{propertyName}</div>
                  <div className="text-sm text-graphite-secondary">{confirmation.property.city}, {confirmation.property.country}</div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-brand-green-dark" />
                <div>
                  <span className="font-medium">{confirmation.booking.check_in}</span>
                  <span className="mx-2">→</span>
                  <span className="font-medium">{confirmation.booking.check_out}</span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Users className="w-5 h-5 text-brand-green-dark" />
                <span>{confirmation.booking.guests} {t('guests')}</span>
              </div>
            </div>
          </div>

          <div className="bg-green-50 rounded-xl p-6 mb-8 text-left">
            <h3 className="font-bold text-graphite mb-4">{t('guest_information')}</h3>
            <div className="grid gap-3">
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-green-600" />
                <span className="text-gray-700">{confirmation.customer.email}</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-green-600" />
                <span className="text-gray-700">{confirmation.customer.phone}</span>
              </div>
            </div>
          </div>

          <div className="bg-brand-green-dark text-white rounded-xl p-6 mb-8">
            <div className="text-sm mb-2">{t('total_amount_paid')}</div>
            <div className="text-4xl font-bold">
              {new Intl.NumberFormat(i18n.language === 'tr' ? 'tr-TR' : 'en-US', { style: 'currency', currency: confirmation.booking.currency, minimumFractionDigits: 0 }).format(confirmation.booking.total_price)}
            </div>
          </div>

          <p className="text-graphite-secondary mb-6">
            {t('confirmation_email_sent', { email: confirmation.customer.email })}
          </p>

          <Button 
            onClick={onBackToSearch}
            className="bg-champagne-gold text-ebony hover:bg-champagne-gold/90 px-8 py-6 text-lg"
          >
            {t('book_another_stay')}
          </Button>
        </div>
      </motion.div>
    </div>
  );
};

export default ConfirmationPage;
