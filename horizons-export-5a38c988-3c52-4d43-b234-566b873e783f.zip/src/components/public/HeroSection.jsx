import React from 'react';
import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import BookingSearchOverlay from './BookingSearchOverlay';
import HotelImageSlider from './HotelImageSlider';

const HeroSection = () => {
  const { t } = useTranslation();

  return (
    <section className="relative h-[80vh] min-h-[600px] md:h-screen flex items-center justify-center text-white overflow-hidden">
      <div className="absolute inset-0 z-0">
        <HotelImageSlider />
        <div className="absolute inset-0 bg-ebony/50"></div>
      </div>

      <div className="relative z-10 container mx-auto px-4 text-center flex flex-col items-center">
        <motion.h1
          className="font-serif text-4xl md:text-6xl lg:text-7xl font-medium mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          {t('hero_title')}
        </motion.h1>
        
        <BookingSearchOverlay />
      </div>
    </section>
  );
};

export default HeroSection;