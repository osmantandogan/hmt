import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useBookingData } from '@/hooks/useBookingData';

const variants = {
  enter: (direction) => {
    return {
      x: direction > 0 ? 1000 : -1000,
      opacity: 0,
    };
  },
  center: {
    zIndex: 1,
    x: 0,
    opacity: 1,
  },
  exit: (direction) => {
    return {
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0,
    };
  },
};

const HotelImageSlider = () => {
  const { properties, loading } = useBookingData();
  const [[page, direction], setPage] = useState([0, 0]);

  const images = useMemo(() => {
    if (properties.length > 0) {
      const allImages = properties.flatMap(p => [
        p.hero_url,
        ...(p.gallery || []),
      ]).filter(Boolean);
      
      const shuffled = allImages.sort(() => 0.5 - Math.random());
      return shuffled.slice(0, 10);
    }
    return [];
  }, [properties]);

  const imageIndex = page % (images.length || 1);

  useEffect(() => {
    if (images.length > 1) {
      const timer = setTimeout(() => {
        setPage([page + 1, 1]);
      }, 5000); // Change image every 5 seconds
      return () => clearTimeout(timer);
    }
  }, [page, images.length]);

  if (loading || images.length === 0) {
    return (
      <div className="w-full h-full object-cover bg-gray-800">
        <img
          className="w-full h-full object-cover"
          alt="Serene and luxurious hotel lobby with minimalist design"
         src="https://images.unsplash.com/photo-1500119478706-30657a4aefc5" />
      </div>
    );
  }

  return (
    <div className="relative w-full h-full">
      <AnimatePresence initial={false} custom={direction}>
        <motion.img
          key={page}
          src={images[imageIndex]}
          custom={direction}
          variants={variants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{
            x: { type: 'spring', stiffness: 300, damping: 30 },
            opacity: { duration: 0.5 },
          }}
          className="absolute h-full w-full object-cover"
          alt="Beautiful hotel view"
        />
      </AnimatePresence>
    </div>
  );
};

export default HotelImageSlider;