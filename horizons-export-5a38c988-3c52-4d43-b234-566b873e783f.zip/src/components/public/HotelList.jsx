import React, { useState, useMemo } from 'react';
import { useBookingData } from '@/hooks/useBookingData';
import PropertyCard from './PropertyCard';
import { Button } from '@/components/ui/button';
import { LayoutGrid, Map } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';

const HotelList = ({ searchParams }) => {
  const { properties, loading } = useBookingData();
  const [view, setView] = useState('grid');
  const { t } = useTranslation();
  const navigate = useNavigate();

  const onSelectProperty = (property) => {
    let url = `/hotel/${property.slug}`;
    const queryParams = new URLSearchParams();
    if (searchParams?.checkin) queryParams.set('checkin', searchParams.checkin);
    if (searchParams?.checkout) queryParams.set('checkout', searchParams.checkout);
    if (searchParams?.adults) queryParams.set('adults', searchParams.adults);
    if (searchParams?.children) queryParams.set('children', searchParams.children);
    
    const queryString = queryParams.toString();
    if (queryString) {
      url += `?${queryString}`;
    }
    navigate(url);
  };

  const activeProperties = useMemo(() => {
    if (!properties) return [];
    return properties
      .filter(p => p.status === 'active')
      .sort((a, b) => {
        if (a.is_featured && !b.is_featured) return -1;
        if (!a.is_featured && b.is_featured) return 1;
        return 0;
      });
  }, [properties]);

  return (
    <section id="hotels" className="bg-ivory py-20">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center mb-12">
          <h2 className="text-4xl font-serif text-graphite mb-4 md:mb-0">{t('hotel_list_title')}</h2>
          <div className="flex items-center gap-2 border border-brand-green-dark/30 rounded-md p-1">
            <Button variant={view === 'grid' ? 'secondary' : 'ghost'} size="sm" onClick={() => setView('grid')}>
              <LayoutGrid className="w-4 h-4 mr-2" />
              {t('view_grid')}
            </Button>
            <Button variant={view === 'map' ? 'secondary' : 'ghost'} size="sm" onClick={() => setView('map')}>
              <Map className="w-4 h-4 mr-2" />
              {t('view_map')}
            </Button>
          </div>
        </div>

        {loading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white/50 rounded-lg shadow-sm animate-pulse">
                <div className="w-full h-56 bg-gray-300 rounded-t-lg"></div>
                <div className="p-6">
                  <div className="h-6 w-3/4 bg-gray-300 rounded mb-2"></div>
                  <div className="h-4 w-1/2 bg-gray-300 rounded"></div>
                </div>
              </div>
            ))}
          </div>
        )}

        {!loading && view === 'grid' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {activeProperties.map(property => (
              <PropertyCard key={property.id} property={property} onSelectProperty={onSelectProperty} searchParams={searchParams} />
            ))}
          </div>
        )}

        {!loading && view === 'map' && (
          <div className="h-[600px] bg-gray-200 rounded-lg flex items-center justify-center">
            <p className="text-graphite-secondary">{t('view_map')} coming soon.</p>
          </div>
        )}
      </div>
    </section>
  );
};

export default HotelList;