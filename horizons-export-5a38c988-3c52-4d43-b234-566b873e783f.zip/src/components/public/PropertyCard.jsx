import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTranslation } from 'react-i18next';
import { useCurrency } from '@/components/layouts/PublicLayout';
import { supabase } from '@/lib/customSupabaseClient';
import { differenceInDays } from 'date-fns';

const PropertyCard = ({ property, onSelectProperty, searchParams }) => {
  const { i18n, t } = useTranslation();
  const { currency, exchangeRate } = useCurrency();
  const [priceInfo, setPriceInfo] = useState({ loading: false, price: null, currency: null });

  const name = property[`name_${i18n.language}`] || property.name_en;
  const description = property[`description_${i18n.language}`] || property.description_en;

  const { checkin, checkout } = searchParams || {};

  useEffect(() => {
    const fetchMinPrice = async () => {
      if (property && checkin && checkout) {
        setPriceInfo({ loading: true, price: null, currency: null });
        const { data, error } = await supabase.rpc('hotel_public_min_price', {
          _property_id: property.id,
          _checkin: checkin,
          _checkout: checkout,
        });

        if (error) {
          console.error('Error fetching min price:', error);
          setPriceInfo({ loading: false, price: null, currency: null });
        } else if (data && data.length > 0) {
          setPriceInfo({ loading: false, price: data[0].total_price, currency: data[0].currency });
        } else {
          setPriceInfo({ loading: false, price: 'not_found', currency: null });
        }
      }
    };

    fetchMinPrice();
  }, [property, checkin, checkout]);

  const getPriceDisplay = () => {
    if (checkin && checkout) {
      if (priceInfo.loading) {
        return <div className="h-6 w-24 bg-gray-200 rounded animate-pulse"></div>;
      }
      if (priceInfo.price === 'not_found') {
        return <span className="text-sm text-red-600">{t('no_rooms_found')}</span>;
      }
      if (priceInfo.price) {
        let price = priceInfo.price;
        if (priceInfo.currency === 'TRY' && currency === 'EUR') {
          price /= exchangeRate;
        } else if (priceInfo.currency === 'EUR' && currency === 'TRY') {
          price *= exchangeRate;
        }
        const formattedPrice = price.toLocaleString(i18n.language === 'tr' ? 'tr-TR' : 'en-US', {
          style: 'currency',
          currency: currency,
          minimumFractionDigits: 0,
        });
        const nights = differenceInDays(new Date(checkout), new Date(checkin));
        return (
          <div>
            <span className="text-xl font-bold text-graphite">{formattedPrice}</span>
            <span className="text-sm text-graphite-secondary ml-1">/ {nights} {t('nights')}</span>
          </div>
        );
      }
    }

    if (property.starting_price) {
      let price = property.starting_price;
      if (property.currency === 'TRY' && currency === 'EUR') {
        price /= exchangeRate;
      } else if (property.currency === 'EUR' && currency === 'TRY') {
        price *= exchangeRate;
      }
      const formattedPrice = price.toLocaleString(i18n.language === 'tr' ? 'tr-TR' : 'en-US', {
        style: 'currency',
        currency: currency,
        minimumFractionDigits: 0,
      });
      return <span className="text-graphite">{t('from_price', { amount: formattedPrice })}</span>;
    }
    return null;
  };

  return (
    <motion.div
      className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300 group flex flex-col"
      whileHover={{ y: -5 }}
    >
      <div className="relative">
        <img
          src={property.hero_image || 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=60'}
          alt={name}
          className="w-full h-56 object-cover transition-transform duration-300 group-hover:scale-105"
        />
        {property.is_featured && (
          <div className="absolute top-3 left-3 bg-brand-green-light text-white text-xs font-bold px-3 py-1 rounded-full">
            {t('featured_badge')}
          </div>
        )}
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-serif text-xl font-medium text-graphite pr-2">{name}</h3>
          {property.rating && (
            <div className="flex items-center gap-1 text-sm text-graphite-secondary flex-shrink-0">
              <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
              <span>{property.rating}</span>
            </div>
          )}
        </div>
        <div className="flex items-center text-sm text-graphite-secondary mb-4">
          <MapPin className="w-4 h-4 mr-1.5" />
          <span>{property.city}, {property.country}</span>
        </div>
        <p className="text-sm text-graphite-secondary mb-4 h-10 overflow-hidden flex-grow">
          {description?.substring(0, 100) || ''}...
        </p>
        <div className="flex justify-between items-center mt-auto">
          <div className="text-lg font-bold">{getPriceDisplay()}</div>
          <Button variant="outline" size="sm" onClick={() => onSelectProperty(property)}>{t('details_button')}</Button>
        </div>
      </div>
    </motion.div>
  );
};

export default PropertyCard;