
import React from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';

const PublicFooter = () => {
  const { t } = useTranslation();

  return (
    <footer className="bg-ivory border-t border-brand-green-dark/20">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
          <div>
            <img src="https://horizons-cdn.hostinger.com/5a38c988-3c52-4d43-b234-566b873e783f/5595b95f4163f9a84a6e22e1fd238ea6.png" alt="HealMedy Travel Logo" className="h-8 mb-4" />
            <nav className="flex flex-col gap-2">
              <Link to="/about" className="text-sm text-graphite-secondary hover:text-graphite">{t('nav_about')}</Link>
              <Link to="/contact" className="text-sm text-graphite-secondary hover:text-graphite">{t('nav_contact')}</Link>
            </nav>
          </div>
          <div>
            <p className="font-serif font-bold text-graphite mb-4">{t('nav_hotels')}</p>
            <nav className="flex flex-col gap-2">
              <Link to="/#hotels" className="text-sm text-graphite-secondary hover:text-graphite">Istanbul</Link>
              <Link to="/#hotels" className="text-sm text-graphite-secondary hover:text-graphite">Antalya</Link>
              <Link to="/#hotels" className="text-sm text-graphite-secondary hover:text-graphite">Cappadocia</Link>
            </nav>
          </div>
          <div>
            <p className="font-serif font-bold text-graphite mb-4">Legal</p>
            <nav className="flex flex-col gap-2">
              <Link to="#" className="text-sm text-graphite-secondary hover:text-graphite">Privacy Policy</Link>
              <Link to="#" className="text-sm text-graphite-secondary hover:text-graphite">Terms of Service</Link>
            </nav>
          </div>
          <div>
            <p className="font-serif font-bold text-graphite mb-4">Social</p>
             <nav className="flex flex-col gap-2">
              <a href="#" className="text-sm text-graphite-secondary hover:text-graphite">Instagram</a>
              <a href="#" className="text-sm text-graphite-secondary hover:text-graphite">Facebook</a>
            </nav>
          </div>
        </div>
        <div className="border-t border-brand-green-dark/20 pt-8 text-center text-sm text-graphite-secondary">
          <p>&copy; {new Date().getFullYear()} HealMedy Travel. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default PublicFooter;
