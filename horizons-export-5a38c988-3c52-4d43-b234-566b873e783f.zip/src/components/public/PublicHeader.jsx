
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { Globe, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTranslation } from 'react-i18next';
import { useCurrency } from '@/components/layouts/PublicLayout';

const PublicHeader = () => {
  const { t, i18n } = useTranslation();
  const { currency, setCurrency } = useCurrency();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();

  const changeLanguage = (lng) => {
    i18n.changeLanguage(lng);
  };

  const toggleCurrency = () => {
    setCurrency(c => c === 'TRY' ? 'EUR' : 'TRY');
  };

  const navLinks = [
    { label: t('nav_hotels'), href: '/' },
    { label: t('nav_tours'), href: '/tours' },
    { label: t('nav_experiences'), href: '/experiences' },
    { label: t('nav_about'), href: '/about' },
    { label: t('nav_contact'), href: '/contact' },
  ];

  return (
    <motion.header 
      className="sticky top-0 z-50 bg-ivory/80 backdrop-blur-lg border-b border-brand-green-dark/20"
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          <Link to="/" className="flex items-center">
            <img src="https://horizons-cdn.hostinger.com/5a38c988-3c52-4d43-b234-566b873e783f/5595b95f4163f9a84a6e22e1fd238ea6.png" alt="HealMedy Travel Logo" className="h-10" />
          </Link>

          <nav className="hidden lg:flex items-center gap-8">
            {navLinks.map(link => (
              <Link key={link.label} to={link.href} className="text-sm font-medium text-graphite-secondary hover:text-graphite transition-colors">
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <div className="hidden lg:flex items-center gap-2">
              <Button variant="ghost" size="sm" onClick={() => changeLanguage(i18n.language === 'tr' ? 'en' : 'tr')}>
                <Globe className="w-4 h-4 mr-2" />
                {i18n.language === 'tr' ? 'EN' : 'TR'}
              </Button>
              <Button variant="ghost" size="sm" onClick={toggleCurrency}>
                {currency}
              </Button>
              <Button variant="outline" onClick={() => navigate('/admin')}>
                {t('manage_booking')}
              </Button>
            </div>
            <button className="lg:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
      
      {isMenuOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-ivory lg:hidden"
        >
          <div className="container mx-auto px-4 pt-5 pb-8">
            <div className="flex justify-between items-center mb-8">
              <Link to="/" className="flex items-center">
                <img src="https://horizons-cdn.hostinger.com/5a38c988-3c52-4d43-b234-566b873e783f/5595b95f4163f9a84a6e22e1fd238ea6.png" alt="HealMedy Travel Logo" className="h-10" />
              </Link>
              <button onClick={() => setIsMenuOpen(false)}>
                <X className="w-6 h-6" />
              </button>
            </div>
            <nav className="flex flex-col gap-6 mb-8">
              {navLinks.map(link => (
                <Link key={link.label} to={link.href} className="text-lg font-medium text-graphite" onClick={() => setIsMenuOpen(false)}>
                  {link.label}
                </Link>
              ))}
            </nav>
            <div className="flex flex-col gap-4">
              <Button variant="outline" onClick={() => { navigate('/admin'); setIsMenuOpen(false); }}>
                {t('manage_booking')}
              </Button>
              <div className="flex justify-center gap-4">
                <Button variant="ghost" onClick={() => { changeLanguage(i18n.language === 'tr' ? 'en' : 'tr'); }}>
                  <Globe className="w-4 h-4 mr-2" />
                  {i18n.language === 'tr' ? 'EN' : 'TR'}
                </Button>
                <Button variant="ghost" onClick={toggleCurrency}>
                  {currency}
                </Button>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </motion.header>
  );
};

export default PublicHeader;
