
import React from 'react';
import { motion } from 'framer-motion';
import { Star, MapPin, Users, Wifi, Coffee, Dumbbell, ArrowLeft, Check, BedDouble, Ruler } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTranslation } from 'react-i18next';

const RoomDetail = ({ room, searchParams, onBookNow, onBack }) => {
  const { t, i18n } = useTranslation();
  const calculateNights = () => {
    if (!searchParams || !searchParams.checkIn || !searchParams.checkOut) return 1;
    const checkIn = new Date(searchParams.checkIn);
    const checkOut = new Date(searchParams.checkOut);
    const nights = Math.ceil((checkOut - checkIn) / (1000 * 60 * 60 * 24));
    return nights > 0 ? nights : 1;
  };

  const nights = calculateNights();
  const totalPrice = room.total_price;
  const roomName = room[`name_${i18n.language}`] || room.name_en;
  const propertyName = room.property[`name_${i18n.language}`] || room.property.name_en;
  const roomDescription = room[`description_${i18n.language}`] || room.description_en || "No description available.";

  const roomPhotos = room.property.gallery ? room.property.gallery.filter(m => m.room_type_id === room.id) : [];
  const heroImage = roomPhotos.length > 0 ? roomPhotos[0].url : 'https://images.unsplash.com/photo-1595526114035-0d45ed16433d?auto=format&fit=crop&w=1200&q=80';

  return (
    <div className="container mx-auto px-4 py-12">
      <Button 
        variant="ghost" 
        onClick={onBack}
        className="mb-6 text-brand-green-dark hover:text-brand-green-light"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        {t('back_to_hotel')}
      </Button>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-white rounded-2xl overflow-hidden shadow-lg"
      >
        <div className="grid md:grid-cols-2 gap-8 p-8">
          <div>
            <img 
              src={heroImage}
              alt={roomName}
              className="w-full h-96 object-cover rounded-xl mb-6"
            />
            
            <div className="grid grid-cols-2 gap-4">
              {roomPhotos.slice(1, 3).map((photo, index) => (
                 <img 
                    key={index}
                    className="w-full h-32 object-cover rounded-lg"
                    alt={`${roomName} view ${index + 1}`}
                    src={photo.url} />
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-start justify-between mb-4">
              <div>
                <h1 className="text-4xl font-serif text-graphite mb-2">{roomName}</h1>
                <h2 className="text-xl text-graphite-secondary mb-3">{propertyName}</h2>
                <div className="flex items-center gap-2 text-graphite-secondary">
                  <MapPin className="w-4 h-4" />
                  <span>{room.property.city}, {room.property.country}</span>
                </div>
              </div>
              <div className="flex items-center gap-1 bg-yellow-100 px-3 py-2 rounded-full">
                <Star className="w-5 h-5 fill-yellow-500 text-yellow-500" />
                <span className="font-semibold text-graphite">{room.property.rating}</span>
              </div>
            </div>

            <p className="text-graphite-secondary mb-6">{roomDescription}</p>

            <div className="bg-ivory/60 rounded-xl p-6 mb-6">
              <h3 className="font-semibold text-graphite mb-4">{t('room_features')}</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-2"><Users className="w-5 h-5 text-brand-green-dark" /><span>{t('max_guests', { count: room.max_adults })}</span></div>
                <div className="flex items-center gap-2"><Ruler className="w-5 h-5 text-brand-green-dark" /><span>{room.size_sqm} m²</span></div>
                <div className="flex items-center gap-2"><BedDouble className="w-5 h-5 text-brand-green-dark" /><span>{room.bed_config}</span></div>
                {room.base_amenities?.map(amenity => (
                  <div key={amenity} className="flex items-center gap-2">
                    <Check className="w-5 h-5 text-brand-green-dark" />
                    <span className="text-graphite capitalize">{t(`amenities_list.${amenity}`, { defaultValue: amenity.replace(/_/g, ' ') })}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t pt-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <div className="text-sm text-graphite-secondary">
                    {nights} {t('nights')}
                  </div>
                  <div className="text-3xl font-bold text-brand-green-dark">
                    {new Intl.NumberFormat(i18n.language === 'tr' ? 'tr-TR' : 'en-US', { style: 'currency', currency: room.currency, minimumFractionDigits: 0 }).format(totalPrice)}
                  </div>
                  <div className="text-sm text-graphite-secondary">
                    {t('total_price')}
                  </div>
                </div>
              </div>

              <Button 
                onClick={() => onBookNow(room)}
                className="w-full py-6 text-lg bg-champagne-gold text-ebony hover:bg-champagne-gold/90 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                {t('proceed_to_checkout')}
              </Button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default RoomDetail;
