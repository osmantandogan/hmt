import React from 'react';
import { motion } from 'framer-motion';
import { Star, MapPin, Users, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useBookingData } from '@/hooks/useBookingData';

const RoomResults = ({ searchParams, onRoomSelect, onBack }) => {
  const { properties, rooms } = useBookingData();

  const filteredProperties = properties.filter(p => 
    p.city.toLowerCase().includes(searchParams.location.toLowerCase()) ||
    p.country.toLowerCase().includes(searchParams.location.toLowerCase())
  );

  return (
    <div className="container mx-auto px-4 py-12">
      <Button 
        variant="ghost" 
        onClick={onBack}
        className="mb-6"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Search
      </Button>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h2 className="text-4xl font-bold gradient-text mb-8">
          Available Hotels in {searchParams.location}
        </h2>

        <div className="grid gap-8">
          {filteredProperties.map((property, idx) => {
            const propertyRooms = rooms.filter(r => r.propertyId === property.id);
            
            return (
              <motion.div
                key={property.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="glass-effect rounded-2xl overflow-hidden card-hover"
              >
                <div className="grid md:grid-cols-3 gap-6 p-6">
                  <div className="md:col-span-1">
                    <img 
                      src={property.image || property.hero_image}
                      alt={property.name}
                      className="w-full h-64 object-cover rounded-xl"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-2xl font-bold text-gray-900 mb-2">{property.name}</h3>
                        <div className="flex items-center gap-2 text-gray-600 mb-3">
                          <MapPin className="w-4 h-4" />
                          <span>{property.location || `${property.city}, ${property.country}`}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 bg-yellow-100 px-3 py-1 rounded-full">
                        <Star className="w-4 h-4 fill-yellow-500 text-yellow-500" />
                        <span className="font-semibold text-gray-900">{property.rating}</span>
                      </div>
                    </div>

                    <p className="text-gray-600 mb-4">{property.description}</p>

                    <div className="flex flex-wrap gap-2 mb-6">
                      {property.amenities.map(amenity => (
                        <span 
                          key={amenity}
                          className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm"
                        >
                          {amenity}
                        </span>
                      ))}
                    </div>

                    <div className="border-t pt-4">
                      <h4 className="font-semibold text-gray-900 mb-3">Available Rooms:</h4>
                      <div className="grid gap-3">
                        {propertyRooms.map(room => (
                          <div 
                            key={room.id}
                            className="flex items-center justify-between p-4 bg-white/50 rounded-xl hover:bg-white/80 transition-colors cursor-pointer"
                            onClick={() => onRoomSelect({ ...room, property })}
                          >
                            <div className="flex items-center gap-4">
                              <img 
                                src={room.image}
                                alt={room.name}
                                className="w-20 h-20 object-cover rounded-lg"
                              />
                              <div>
                                <h5 className="font-semibold text-gray-900">{room.name}</h5>
                                <div className="flex items-center gap-2 text-sm text-gray-600">
                                  <Users className="w-4 h-4" />
                                  <span>Up to {room.capacity} guests</span>
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-2xl font-bold text-blue-600">
                                ${room.basePrice}
                              </div>
                              <div className="text-sm text-gray-500">per night</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </motion.div>
    </div>
  );
};

export default RoomResults;