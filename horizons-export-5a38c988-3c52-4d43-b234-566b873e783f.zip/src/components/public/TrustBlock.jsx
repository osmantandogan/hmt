import React from 'react';
import { ShieldCheck, CreditCard, PhoneCall } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const TrustBlock = () => {
  const { t } = useTranslation();

  const items = [
    { icon: ShieldCheck, text: t('trust_cancellation') },
    { icon: CreditCard, text: t('trust_payment') },
    { icon: PhoneCall, text: t('trust_support') },
  ];

  return (
    <section className="bg-ivory py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          {items.map((item, index) => (
            <div key={index} className="flex flex-col items-center">
              <item.icon className="w-8 h-8 text-champagne-gold mb-3" />
              <p className="text-graphite font-medium">{item.text}</p>
            </div>
          ))}
        </div>
        <div className="w-24 h-px bg-champagne-gold/50 mx-auto mt-16"></div>
      </div>
    </section>
  );
};

export default TrustBlock;