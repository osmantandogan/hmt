import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext(undefined);

export const AuthProvider = ({ children }) => {
  const { toast } = useToast();

  const [user, setUser] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  const handleSession = useCallback(async (session) => {
    setSession(session);
    setUser(session?.user ?? null);
    setLoading(false);
  }, []);

  useEffect(() => {
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      handleSession(session);
    };

    getSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        handleSession(session);
      }
    );

    return () => subscription.unsubscribe();
  }, [handleSession]);

  const signUp = useCallback(async (email, password, options) => {
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options,
    });

    if (error) {
      toast({
        variant: "destructive",
        title: "Sign up Failed",
        description: error.message || "Something went wrong",
      });
    }

    return { error };
  }, [toast]);

  const signIn = useCallback(async (email, password) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      toast({
        variant: "destructive",
        title: "Sign in Failed",
        description: error.message || "Something went wrong",
      });
    }

    return { error };
  }, [toast]);

  const signInWithGoogle = useCallback(async () => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
    });

    if (error) {
      toast({
        variant: "destructive",
        title: "Google Sign-in Failed",
        description: error.message || "Something went wrong",
      });
    }
  }, [toast]);

  const signInWithPhone = useCallback(async (phone) => {
    const { data, error } = await supabase.auth.signInWithOtp({
      phone,
    });
    if (error) {
      toast({
        variant: "destructive",
        title: "Phone Sign-in Failed",
        description: error.message || "Could not send OTP.",
      });
    }
    return { data, error };
  }, [toast]);

  const verifyOtp = useCallback(async (phone, token) => {
    const { data, error } = await supabase.auth.verifyOtp({
      phone,
      token,
      type: 'sms',
    });
     if (error) {
      toast({
        variant: "destructive",
        title: "OTP Verification Failed",
        description: error.message || "Invalid OTP.",
      });
    }
    return { data, error };
  }, [toast]);

  const signOut = useCallback(async () => {
    const { error } = await supabase.auth.signOut();

    if (error) {
      toast({
        variant: "destructive",
        title: "Sign out Failed",
        description: error.message || "Something went wrong",
      });
    }

    return { error };
  }, [toast]);

  const signUpWithPhone = useCallback(async (phone) => {
    const { data, error } = await supabase.auth.signInWithOtp({
      phone,
    });
    if (error) {
      toast({
        variant: "destructive",
        title: "Phone Sign-up Failed",
        description: error.message || "Could not send OTP.",
      });
    }
    return { data, error };
  }, [toast]);

  const verifyPhoneSignUp = useCallback(async (phone, token, fullName) => {
    const { data, error } = await supabase.auth.verifyOtp({
      phone,
      token,
      type: 'sms',
    });
    if (error) {
      toast({
        variant: "destructive",
        title: "OTP Verification Failed",
        description: error.message || "Invalid OTP.",
      });
      return { data, error };
    }
    // If OTP is correct, update the user's metadata
    if (data.user) {
      const { error: updateError } = await supabase.auth.updateUser({
        data: { full_name: fullName, role: 'customer' }
      });
      if (updateError) {
        toast({
          variant: "destructive",
          title: "Profile Update Failed",
          description: updateError.message,
        });
        return { data: null, error: updateError };
      }
    }
    return { data, error };
  }, [toast]);

  const createStaffUser = useCallback(async (email, password, role, fullName) => {
    const { data, error } = await supabase.functions.invoke('create-user', {
      body: { email, password, role, fullName },
    });

    if (error) {
      toast({
        variant: "destructive",
        title: "Personel Oluşturulamadı",
        description: error.message || "Bir şeyler ters gitti.",
      });
    } else {
      toast({
        title: "Personel Oluşturuldu! 🚀",
        description: `${fullName} adlı kullanıcı için hesap oluşturuldu. Onay e-postası gönderildi.`,
      });
    }

    return { data, error };
  }, [toast]);


  const value = useMemo(() => ({
    user,
    session,
    loading,
    signUp,
    signIn,
    signInWithGoogle,
    signInWithPhone,
    verifyOtp,
    signOut,
    signUpWithPhone,
    verifyPhoneSignUp,
    createStaffUser,
  }), [user, session, loading, signUp, signIn, signInWithGoogle, signInWithPhone, verifyOtp, signOut, signUpWithPhone, verifyPhoneSignUp, createStaffUser]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};