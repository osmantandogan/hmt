import { useState, useEffect } from 'react';

export const useAuth = () => {
  const [user, setUser] = useState(null);
  const [role, setRole] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const storedUser = localStorage.getItem('healmedy_user');
    const storedRole = localStorage.getItem('healmedy_role');
    
    if (storedUser && storedRole) {
      setUser(JSON.parse(storedUser));
      setRole(storedRole);
    }
    
    setLoading(false);
  }, []);

  const login = (email, password) => {
    const mockUser = {
      id: '1',
      email: email,
      name: email.split('@')[0],
    };
    
    let userRole = 'guest';
    if (email.includes('admin')) userRole = 'admin';
    else if (email.includes('manager')) userRole = 'manager';
    else if (email.includes('supervisor')) userRole = 'supervisor';
    else if (email.includes('agent')) userRole = 'agent';
    
    localStorage.setItem('healmedy_user', JSON.stringify(mockUser));
    localStorage.setItem('healmedy_role', userRole);
    
    setUser(mockUser);
    setRole(userRole);
    
    return { user: mockUser, role: userRole };
  };

  const logout = () => {
    localStorage.removeItem('healmedy_user');
    localStorage.removeItem('healmedy_role');
    setUser(null);
    setRole(null);
  };

  return { user, role, loading, login, logout };
};