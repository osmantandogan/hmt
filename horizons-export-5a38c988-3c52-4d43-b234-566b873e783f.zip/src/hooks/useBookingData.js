import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';

export const useBookingData = () => {
  const [properties, setProperties] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [tours, setTours] = useState([]);
  const [tourCategories, setTourCategories] = useState([]);
  const [appSettings, setAppSettings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchData = useCallback(async () => {
    setError(null);

    try {
      const [
        propertiesRes,
        roomsRes,
        bookingsRes,
        customersRes,
        toursRes,
        tourCategoriesRes,
        appSettingsRes
      ] = await Promise.all([
        supabase.from('v_public_properties').select('*'),
        supabase.from('room_types').select('*'),
        supabase.from('bookings').select('*'),
        supabase.from('customers').select('*'),
        supabase.from('tours').select('*, tour_price_rules(*)'),
        supabase.from('tour_categories').select('*'),
        supabase.from('app_settings').select('*').single()
      ]);

      if (propertiesRes.error) throw propertiesRes.error;
      if (roomsRes.error) throw roomsRes.error;
      if (bookingsRes.error) throw bookingsRes.error;
      if (customersRes.error) throw customersRes.error;
      if (toursRes.error) throw toursRes.error;
      if (tourCategoriesRes.error) throw tourCategoriesRes.error;
      if (appSettingsRes.error && appSettingsRes.status !== 406) throw appSettingsRes.error;

      setProperties(propertiesRes.data);
      setRooms(roomsRes.data);
      setBookings(bookingsRes.data);
      setCustomers(customersRes.data);
      setTours(toursRes.data);
      setTourCategories(tourCategoriesRes.data);
      setAppSettings(appSettingsRes.data);

    } catch (err) {
      console.error("Error fetching booking data:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();

    const channel = supabase
      .channel('public-db-changes')
      .on('postgres_changes', { event: '*', schema: 'public' }, (payload) => {
        console.log('DB change received!', payload);
        fetchData();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchData]);

  return { properties, rooms, bookings, customers, tours, tourCategories, appSettings, loading, error, refetch: fetchData };
};