
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    debug: true,
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false,
    },
    resources: {
      en: {
        translation: {
          // Header
          nav_hotels: 'Hotels',
          nav_tours: 'Tours',
          nav_experiences: 'Experiences',
          nav_about: 'About Us',
          nav_contact: 'Contact',
          manage_booking: 'Manage My Booking',
          // Hero
          hero_title: 'Timeless Stays, Curated for You',
          search_destination: 'Destination or hotel',
          search_checkin: 'Check-in',
          search_checkout: 'Check-out',
          search_guests: 'Guests',
          search_promo: 'Use a code',
          search_cta: 'Check Availability',
          // Trust Block
          trust_cancellation: 'Flexible Cancellation',
          trust_payment: '3D Secure Payment',
          trust_support: '24/7 Support',
          // Hotel List
          hotel_list_title: 'Our Exclusive Collection',
          filter_location: 'Location',
          filter_price: 'Price Range',
          filter_stars: 'Stars',
          filter_amenities: 'Amenities',
          sort_by: 'Sort by',
          sort_recommended: 'Recommended',
          sort_price_asc: 'Price (Low to High)',
          sort_price_desc: 'Price (High to Low)',
          view_map: 'Map View',
          view_grid: 'Grid View',
          // Property Card
          price_per_night: 'per night',
          featured_badge: 'Featured',
          new_badge: 'New',
          details_button: 'View Details',
          book_now_button: 'Book Now',
          // Call Center
          call_center_title: '24/7 Reservation Support',
          // Detail Page & Common
          back_to_hotels: "Back to hotels",
          about_hotel: "About the Hotel",
          amenities: "Amenities",
          available_rooms: "Available Rooms",
          no_rooms_found: "No rooms found for these dates.",
          from_price: "From {{amount}} per night",
          select_dates_to_view_rooms: "Select dates to view available rooms",
          view_details: "View Details",
          change_dates: "Change Dates",
          max_guests: "Up to {{count}} guests",
          night: "night",
          nights: "nights",
          book_now: "Book Now",
          loading_rooms: "Loading rooms...",
          no_rooms_found_for_property: "No rooms found for this property.",
          total_price: "{{amount}} total",
          amenities_list: {
            "spa": "Spa",
            "gym": "Gym",
            "parking": "Parking",
            "airport_shuttle": "Airport shuttle",
            "meeting_rooms": "Meeting rooms",
            "wifi_free": "Free Wi-Fi",
            "kids_club": "Kids club",
            "restaurant": "Restaurant",
            "ev_charger": "EV charger",
            "sea_view": "Sea view",
            "pool_indoor": "Indoor pool",
            "pool_outdoor": "Outdoor pool",
            "bar": "Bar",
            "accessible_rooms": "Accessible rooms",
            "city_view": "City view",
            "pet_friendly": "Pet friendly"
          }
        },
      },
      tr: {
        translation: {
          // Header
          nav_hotels: 'Oteller',
          nav_tours: 'Turlar',
          nav_experiences: 'Deneyimler',
          nav_about: 'Biz Kimiz',
          nav_contact: 'İletişim',
          manage_booking: 'Rezervasyonumu Yönet',
          // Hero
          hero_title: 'Zamansız Konaklama Deneyimi',
          search_destination: 'Destinasyon veya otel',
          search_checkin: 'Giriş Tarihi',
          search_checkout: 'Çıkış Tarihi',
          search_guests: 'Misafir',
          search_promo: 'Kodu kullan',
          search_cta: 'Müsaitlik Ara',
          // Trust Block
          trust_cancellation: 'Esnek İptal',
          trust_payment: '3D Secure Ödeme',
          trust_support: '7/24 Destek',
          // Hotel List
          hotel_list_title: 'Ayrıcalıklı Koleksiyonumuz',
          filter_location: 'Konum',
          filter_price: 'Fiyat Aralığı',
          filter_stars: 'Yıldız',
          filter_amenities: 'Olanaklar',
          sort_by: 'Sırala',
          sort_recommended: 'Önerilen',
          sort_price_asc: 'Fiyat (Artan)',
          sort_price_desc: 'Fiyat (Azalan)',
          view_map: 'Harita Görünümü',
          view_grid: 'Grid Görünümü',
          // Property Card
          price_per_night: 'gecelik',
          featured_badge: 'Öne Çıkan',
          new_badge: 'Yeni',
          details_button: 'Otel Detayı',
          book_now_button: 'Hızlı Rezervasyon',
          // Call Center
          call_center_title: '7/24 Rezervasyon Desteği',
          // Detail Page & Common
          back_to_hotels: "Otellere dön",
          about_hotel: "Otel Hakkında",
          amenities: "Olanaklar",
          available_rooms: "Müsait Odalar",
          no_rooms_found: "Bu tarihlerde müsait oda bulunamadı.",
          from_price: "Gecelik {{amount}}'den başlayan fiyatlarla",
          select_dates_to_view_rooms: "Müsait odaları görmek için tarih seçin",
          view_details: "Detayları Gör",
          change_dates: "Tarihleri Değiştir",
          max_guests: "{{count}} misafire kadar",
          night: "gece",
          nights: "gece",
          book_now: "Rezervasyon Yap",
          loading_rooms: "Odalar yükleniyor...",
          no_rooms_found_for_property: "Bu otel için oda bulunamadı.",
          total_price: "Toplam {{amount}}",
          amenities_list: {
            "spa": "Spa",
            "gym": "Spor salonu",
            "parking": "Otopark",
            "airport_shuttle": "Havaalanı servisi",
            "meeting_rooms": "Toplantı salonları",
            "wifi_free": "Ücretsiz Wi-Fi",
            "kids_club": "Çocuk kulübü",
            "restaurant": "Restoran",
            "ev_charger": "Elektrikli araç şarjı",
            "sea_view": "Deniz manzarası",
            "pool_indoor": "Kapalı havuz",
            "pool_outdoor": "Açık havuz",
            "bar": "Bar",
            "accessible_rooms": "Erişilebilir odalar",
            "city_view": "Şehir manzarası",
            "pet_friendly": "Evcil hayvan kabul edilir"
          }
        },
      },
    },
  });

export default i18n;
