
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Award, Heart, Map, Users } from 'lucide-react';

const StatCard = ({ icon, value, label }) => (
  <motion.div 
    className="bg-white p-6 rounded-2xl shadow-lg text-center"
    whileHover={{ scale: 1.05, y: -5 }}
    transition={{ type: 'spring', stiffness: 300 }}
  >
    <div className="flex justify-center mb-4">{icon}</div>
    <p className="text-4xl font-bold text-brand-green-dark">{value}</p>
    <p className="text-graphite-secondary">{label}</p>
  </motion.div>
);

const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>Hakkımızda - HealMedy Travel</title>
        <meta name="description" content="HealMedy Travel'ın hikayesini, misyonunu ve vizyonunu keşfedin. Size özel seyahat deneyimleri sunuyoruz." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="relative h-96">
          <img alt="Huzurlu bir otel lobisi" className="absolute inset-0 w-full h-full object-cover" src="https://images.unsplash.com/photo-1644473968199-150d0a098163" />
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <motion.h1 
              className="text-5xl md:text-7xl font-serif font-bold text-white text-center"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
            >
              Bizim Hikayemiz
            </motion.h1>
          </div>
        </div>

        <div className="container mx-auto px-4 py-20">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-4xl font-serif font-bold text-brand-green-dark mb-4">Seyahatin Sanat Hali</h2>
            <p className="text-lg text-graphite-secondary">
              HealMedy Travel olarak, seyahatin sadece bir yerden bir yere gitmek olmadığına inanıyoruz. Bizim için seyahat, ruhu besleyen, yeni ufuklar açan ve unutulmaz anılar biriktiren bir sanattır. Bu felsefeyle, Türkiye'nin en seçkin otellerini ve deneyimlerini sizin için bir araya getiriyoruz.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
            <StatCard icon={<Heart className="w-12 h-12 text-brand-green-light" />} value="10,000+" label="Mutlu Misafir" />
            <StatCard icon={<Award className="w-12 h-12 text-brand-green-light" />} value="200+" label="Seçkin Otel" />
            <StatCard icon={<Map className="w-12 h-12 text-brand-green-light" />} value="15" label="Destinasyon" />
            <StatCard icon={<Users className="w-12 h-12 text-brand-green-light" />} value="50+" label="Deneyimli Ekip" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl font-serif font-bold text-brand-green-dark mb-4">Misyonumuz & Vizyonumuz</h3>
              <p className="text-graphite-secondary mb-4">
                <strong>Misyonumuz:</strong> Misafirlerimize sadece konaklama değil, aynı zamanda ömür boyu hatırlayacakları, kişiye özel ve kusursuz seyahat deneyimleri sunmak.
              </p>
              <p className="text-graphite-secondary">
                <strong>Vizyonumuz:</strong> Türkiye'de lüks ve butik seyahat denildiğinde akla gelen ilk ve en güvenilir marka olmak, teknolojiyi insan dokunuşuyla birleştirerek seyahat standartlarını yeniden tanımlamak.
              </p>
            </div>
            <motion.div 
              className="rounded-2xl overflow-hidden shadow-xl"
              initial={{ scale: 0.9, opacity: 0 }}
              whileInView={{ scale: 1, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <img alt="HealMedy Travel ekibi toplantıda" className="w-full h-auto object-cover" src="https://images.unsplash.com/photo-1632988145743-d9a12226d2a8" />
            </motion.div>
          </div>
        </div>
      </motion.div>
    </>
  );
};

export default AboutPage;
