
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Phone, Mail, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';

const ContactPage = () => {
  const { toast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    toast({
      title: "🚧 Bu özellik henüz tamamlanmadı!",
      description: "Ancak endişelenmeyin! Bir sonraki isteğinizde bunu talep edebilirsiniz! 🚀",
    });
  };

  return (
    <>
      <Helmet>
        <title>İletişim - HealMedy Travel</title>
        <meta name="description" content="HealMedy Travel ile iletişime geçin. Sorularınız, önerileriniz veya rezervasyon talepleriniz için buradayız." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="bg-gradient-to-b from-brand-green-light/10 to-ivory py-20">
          <div className="container mx-auto px-4 text-center">
            <motion.h1 
              className="text-4xl md:text-6xl font-serif font-bold text-brand-green-dark mb-4"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
            >
              Bize Ulaşın
            </motion.h1>
            <motion.p 
              className="max-w-2xl mx-auto text-lg text-graphite-secondary"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.5 }}
            >
              Hayalinizdeki tatil için bir sorunuz mu var? Size yardımcı olmaktan mutluluk duyarız.
            </motion.p>
          </div>
        </div>

        <div className="container mx-auto px-4 py-20">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2 bg-white p-8 rounded-2xl shadow-lg">
              <h2 className="text-3xl font-serif font-bold text-brand-green-dark mb-6">Mesaj Gönderin</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Input placeholder="Adınız" className="py-6" />
                  <Input type="email" placeholder="E-posta Adresiniz" className="py-6" />
                </div>
                <Input placeholder="Konu" className="py-6" />
                <Textarea placeholder="Mesajınız..." rows={6} />
                <Button type="submit" size="lg" className="w-full bg-brand-green-dark hover:bg-brand-green-dark/90">Mesajı Gönder</Button>
              </form>
            </div>
            
            <div className="space-y-8">
              <div className="bg-white p-8 rounded-2xl shadow-lg">
                <h3 className="text-2xl font-serif font-bold text-brand-green-dark mb-4">İletişim Bilgileri</h3>
                <div className="space-y-4 text-graphite-secondary">
                  <div className="flex items-start">
                    <MapPin className="w-6 h-6 mr-4 text-brand-green-light mt-1 flex-shrink-0" />
                    <span>123 Lüks Cadde, Beşiktaş, İstanbul, Türkiye</span>
                  </div>
                  <div className="flex items-center">
                    <Mail className="w-6 h-6 mr-4 text-brand-green-light" />
                    <a href="mailto:info@healmedytravel.com" className="hover:text-brand-green-dark">info@healmedytravel.com</a>
                  </div>
                  <div className="flex items-center">
                    <Phone className="w-6 h-6 mr-4 text-brand-green-light" />
                    <a href="tel:+902121234567" className="hover:text-brand-green-dark">+90 212 123 45 67</a>
                  </div>
                </div>
              </div>
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden h-64">
                <img alt="Ofisimizin konumu haritada" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1692822380369-464ff73f1b42" />
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </>
  );
};

export default ContactPage;
