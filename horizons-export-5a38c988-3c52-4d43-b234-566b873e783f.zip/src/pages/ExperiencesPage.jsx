
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Utensils, Wind, Heart, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const ExperienceCard = ({ experience }) => {
  const { toast } = useToast();

  const handleDiscover = () => {
    toast({
      title: "🚧 Bu özellik henüz tamamlanmadı!",
      description: "Ancak endişelenmeyin! Bir sonraki isteğinizde bunu talep edebilirsiniz! 🚀",
    });
  };

  return (
    <motion.div 
      className="relative rounded-2xl overflow-hidden shadow-2xl group"
      whileHover={{ scale: 1.02 }}
      transition={{ type: 'spring', stiffness: 300 }}
    >
      <img alt={experience.title} className="w-full h-96 object-cover transform group-hover:scale-110 transition-transform duration-700" src="https://images.unsplash.com/photo-1507238691740-187a5b1d37b8" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
      <div className="absolute bottom-0 left-0 p-8 text-white">
        <div className="mb-4">{experience.icon}</div>
        <h3 className="text-3xl font-serif font-bold mb-2">{experience.title}</h3>
        <p className="text-white/80 mb-6">{experience.description}</p>
        <Button onClick={handleDiscover} variant="secondary">Keşfet</Button>
      </div>
    </motion.div>
  );
};

const ExperiencesPage = () => {
  const experiences = [
    {
      id: 1,
      title: 'Gurme Lezzetler',
      description: 'Usta şeflerin elinden çıkan, yerel ve uluslararası mutfakların en özel tatlarını deneyimleyin.',
      icon: <Utensils className="w-10 h-10 text-white" />,
    },
    {
      id: 2,
      title: 'Spa & Wellness',
      description: 'Bedeninizi ve ruhunuzu dinlendirecek, size özel tasarlanmış spa ve wellness programlarıyla yenilenin.',
      icon: <Wind className="w-10 h-10 text-white" />,
    },
    {
      id: 3,
      title: 'Romantik Kaçamaklar',
      description: 'Partnerinizle unutulmaz anlar yaşayacağınız, büyüleyici manzaralara sahip romantik paketler.',
      icon: <Heart className="w-10 h-10 text-white" />,
    },
    {
      id: 4,
      title: 'Özel Plaj Ayrıcalığı',
      description: 'Sadece size özel plajlarda güneşin ve denizin tadını çıkarın, kalabalıktan uzak bir tatil yaşayın.',
      icon: <Sun className="w-10 h-10 text-white" />,
    },
  ];

  return (
    <>
      <Helmet>
        <title>Deneyimler - HealMedy Travel</title>
        <meta name="description" content="HealMedy Travel'ın sunduğu gurme lezzetler, spa, romantik kaçamaklar gibi özel deneyimleri keşfedin." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="bg-gradient-to-b from-brand-green-light/10 to-ivory py-20">
          <div className="container mx-auto px-4 text-center">
            <motion.h1 
              className="text-4xl md:text-6xl font-serif font-bold text-brand-green-dark mb-4"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
            >
              Size Özel Deneyimler
            </motion.h1>
            <motion.p 
              className="max-w-2xl mx-auto text-lg text-graphite-secondary"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.5 }}
            >
              Konaklamanızdan daha fazlasını sunuyoruz. Tatilinizi unutulmaz kılacak anılar biriktirin.
            </motion.p>
          </div>
        </div>

        <div className="container mx-auto px-4 py-20">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {experiences.map((exp, index) => (
              <motion.div
                key={exp.id}
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
              >
                <ExperienceCard experience={exp} />
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>
    </>
  );
};

export default ExperiencesPage;
