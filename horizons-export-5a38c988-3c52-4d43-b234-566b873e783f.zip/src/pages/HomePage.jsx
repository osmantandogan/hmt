
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import HeroSection from '@/components/public/HeroSection';
import TrustBlock from '@/components/public/TrustBlock';
import HotelList from '@/components/public/HotelList';
import CallCenterBanner from '@/components/public/CallCenterBanner';

const HomePage = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useState({});

  const handleSelectProperty = (property) => {
    const query = new URLSearchParams(searchParams).toString();
    navigate(`/hotel/${property.slug}?${query}`);
  };

  const handleSearch = (params) => {
    setSearchParams(params);
  };

  return (
    <>
      <HeroSection onSearch={handleSearch} />
      <TrustBlock />
      <HotelList onSelectProperty={handleSelectProperty} searchParams={searchParams} />
      <CallCenterBanner />
    </>
  );
};

export default HomePage;
