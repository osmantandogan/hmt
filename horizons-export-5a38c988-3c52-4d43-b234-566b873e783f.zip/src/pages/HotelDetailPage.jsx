
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, MapPin, Star, Wifi, CheckCircle2, BedDouble, Users, Ruler } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useBookingData } from '@/hooks/useBookingData';
import { useCurrency } from '@/components/layouts/PublicLayout';
import { useToast } from "@/components/ui/use-toast";
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/customSupabaseClient';
import { differenceInDays, format } from 'date-fns';
import RoomDetail from '@/components/public/RoomDetail';
import CheckoutPage from '@/components/public/CheckoutPage';
import ConfirmationPage from '@/components/public/ConfirmationPage';

const amenityIcons = {
  'spa': <CheckCircle2 className="w-5 h-5 text-brand-green-dark" />,
  'gym': <CheckCircle2 className="w-5 h-5 text-brand-green-dark" />,
  'parking': <CheckCircle2 className="w-5 h-5 text-brand-green-dark" />,
  'airport_shuttle': <CheckCircle2 className="w-5 h-5 text-brand-green-dark" />,
  'meeting_rooms': <CheckCircle2 className="w-5 h-5 text-brand-green-dark" />,
  'wifi_free': <Wifi className="w-5 h-5 text-brand-green-dark" />,
  'kids_club': <CheckCircle2 className="w-5 h-5 text-brand-green-dark" />,
  'restaurant': <CheckCircle2 className="w-5 h-5 text-brand-green-dark" />,
  'ev_charger': <CheckCircle2 className="w-5 h-5 text-brand-green-dark" />,
  'sea_view': <CheckCircle2 className="w-5 h-5 text-brand-green-dark" />,
  'pool_indoor': <CheckCircle2 className="w-5 h-5 text-brand-green-dark" />,
  'pool_outdoor': <CheckCircle2 className="w-5 h-5 text-brand-green-dark" />,
  'bar': <CheckCircle2 className="w-5 h-5 text-brand-green-dark" />,
  'accessible_rooms': <CheckCircle2 className="w-5 h-5 text-brand-green-dark" />,
  'city_view': <CheckCircle2 className="w-5 h-5 text-brand-green-dark" />,
  'pet_friendly': <CheckCircle2 className="w-5 h-5 text-brand-green-dark" />,
  'default': <CheckCircle2 className="w-5 h-5 text-brand-green-dark" />
};

const HotelDetailPage = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const { properties, rooms, loading } = useBookingData();
  const { i18n, t } = useTranslation();
  const { currency, exchangeRate } = useCurrency();
  const { toast } = useToast();
  
  const [availableRooms, setAvailableRooms] = useState([]);
  const [roomsLoading, setRoomsLoading] = useState(false);
  const [bookingStep, setBookingStep] = useState('details'); // details, room, checkout, confirmation
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [confirmationData, setConfirmationData] = useState(null);

  const searchParams = new URLSearchParams(location.search);
  const checkinDate = searchParams.get('checkin');
  const checkoutDate = searchParams.get('checkout');
  const guests = searchParams.get('guests');

  const property = properties.find(p => p.slug === slug);

  useEffect(() => {
    const fetchAvailableRooms = async () => {
      if (property && checkinDate && checkoutDate) {
        setRoomsLoading(true);
        const { data, error } = await supabase.rpc('hotel_public_min_price', {
          _property_id: property.id,
          _checkin: checkinDate,
          _checkout: checkoutDate,
        });

        if (error) {
          console.error('Error fetching min price rooms:', error);
          toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch room prices.' });
        } else {
          setAvailableRooms(data || []);
        }
        setRoomsLoading(false);
      }
    };

    if (property) {
        fetchAvailableRooms();
    }
  }, [property, checkinDate, checkoutDate, toast]);

  const handleBookNow = (room) => {
    const fullRoom = rooms.find(r => r.id === room.room_type_id);
    if (fullRoom) {
      setSelectedRoom({ ...fullRoom, ...room, property });
      setBookingStep('room');
    }
  };

  const handleProceedToCheckout = () => {
    setBookingStep('checkout');
  };

  const handleBookingComplete = (data) => {
    setConfirmationData(data);
    setBookingStep('confirmation');
  };

  const handleBackToSearch = () => {
    setBookingStep('details');
    setSelectedRoom(null);
    setConfirmationData(null);
    navigate('/');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-ivory">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-green-light"></div>
      </div>
    );
  }

  if (!property) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-ivory text-center">
        <h2 className="text-3xl font-serif text-brand-green-dark mb-4">Otel Bulunamadı</h2>
        <p className="text-graphite-secondary mb-8">Aradığınız otel mevcut değil veya kaldırılmış olabilir.</p>
        <Button onClick={() => navigate('/')}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Ana Sayfaya Dön
        </Button>
      </div>
    );
  }

  if (bookingStep === 'room' && selectedRoom) {
    return <RoomDetail 
      room={selectedRoom} 
      searchParams={{ checkIn: checkinDate, checkOut: checkoutDate, guests }}
      onBookNow={handleProceedToCheckout} 
      onBack={() => setBookingStep('details')} 
    />;
  }

  if (bookingStep === 'checkout' && selectedRoom) {
    return <CheckoutPage 
      bookingData={{ room: selectedRoom, searchParams: { checkIn: checkinDate, checkOut: checkoutDate, guests } }}
      onComplete={handleBookingComplete}
      onBack={() => setBookingStep('room')}
    />;
  }

  if (bookingStep === 'confirmation' && confirmationData) {
    return <ConfirmationPage 
      confirmation={confirmationData}
      onBackToSearch={handleBackToSearch}
    />;
  }

  const name = property[`name_${i18n.language}`] || property.name_en;
  const description = property[`description_${i18n.language}`] || property.description_en;

  const getPrice = (price, originalCurrency) => {
    let p = price;
    if (originalCurrency === 'TRY' && currency === 'EUR') {
      p /= exchangeRate;
    } else if (originalCurrency === 'EUR' && currency === 'TRY') {
      p *= exchangeRate;
    }
    return p.toLocaleString(i18n.language === 'tr' ? 'tr-TR' : 'en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0,
    });
  };
  
  const propertyRooms = rooms.filter(r => r.property_id === property.id && r.is_active);
  const nights = checkinDate && checkoutDate ? differenceInDays(new Date(checkoutDate), new Date(checkinDate)) : 0;

  return (
    <>
      <Helmet>
        <title>{`${name} - HealMedy Travel`}</title>
        <meta name="description" content={description ? description.substring(0, 160) : ''} />
      </Helmet>
      <div className="bg-ivory">
        <div className="container mx-auto px-4 py-12">
          <Button variant="ghost" onClick={() => navigate(-1)} className="mb-8 text-brand-green-dark hover:text-brand-green-light">
            <ArrowLeft className="w-4 h-4 mr-2" />
            {t('back_to_hotels')}
          </Button>

          <header className="mb-12">
            <div className="flex flex-col md:flex-row justify-between md:items-center mb-4">
              <h1 className="text-5xl font-serif text-graphite mb-2 md:mb-0">{name}</h1>
              {property.stars && (
                <div className="flex items-center gap-2">
                  {[...Array(property.stars)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                  ))}
                </div>
              )}
            </div>
            <div className="flex items-center text-graphite-secondary">
              <MapPin className="w-5 h-5 mr-2" />
              <span>{property.city}, {property.country}</span>
            </div>
          </header>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <main className="lg:col-span-2">
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
                <div className="w-full h-[500px] rounded-lg overflow-hidden mb-4">
                  <img
                    src={property.hero_url || 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80'}
                    alt={name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {(property.gallery || []).slice(0, 4).map((img, i) => (
                    <div key={i} className="w-full h-24 rounded-md overflow-hidden">
                      <img src={img.url} alt={`${name} gallery image ${i+1}`} className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>
              </motion.div>

              <section id="description" className="mt-12">
                <h2 className="text-3xl font-serif text-graphite mb-4">{t('about_hotel')}</h2>
                <p className="text-graphite-secondary leading-relaxed">{description}</p>
              </section>

              <section id="amenities" className="mt-12">
                <h2 className="text-3xl font-serif text-graphite mb-6">{t('amenities')}</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                  {(property.amenities || []).map(amenity => (
                    <div key={amenity} className="flex items-center gap-3">
                      {amenityIcons[amenity] || amenityIcons.default}
                      <span className="text-graphite">{t(`amenities_list.${amenity}`, { defaultValue: amenity.replace(/_/g, ' ') })}</span>
                    </div>
                  ))}
                </div>
              </section>
            </main>

            <aside className="lg:col-span-1">
              <div className="sticky top-24">
                <h2 className="text-3xl font-serif text-graphite mb-6">{t('available_rooms')}</h2>
                <div className="space-y-6">
                  {roomsLoading ? (
                    <p>{t('loading_rooms')}</p>
                  ) : availableRooms.length > 0 ? (
                    availableRooms.map(room => {
                      const fullRoom = propertyRooms.find(r => r.id === room.room_type_id);
                      return (
                        <div key={room.room_type_id} className="bg-white p-6 rounded-lg shadow-sm border border-gray-200/80">
                          <h3 className="text-xl font-bold text-graphite mb-3">{room[`room_name_${i18n.language}`] || room.room_name_en}</h3>
                          {fullRoom && (
                            <div className="text-sm text-graphite-secondary space-y-2 mb-4">
                              <div className="flex items-center gap-2"><Users className="w-4 h-4" /><span>{t('max_guests', { count: fullRoom.max_adults })}</span></div>
                              <div className="flex items-center gap-2"><Ruler className="w-4 h-4" /><span>{fullRoom.size_sqm} m²</span></div>
                              <div className="flex items-center gap-2"><BedDouble className="w-4 h-4" /><span>{fullRoom.bed_config}</span></div>
                            </div>
                          )}
                          <div className="flex justify-between items-center">
                            <div>
                              <span className="text-lg font-bold text-brand-green-dark">{getPrice(room.total_price, room.currency)}</span>
                              <span className="text-sm text-graphite-secondary ml-1">/ {nights} {t('nights')}</span>
                            </div>
                            <Button onClick={() => handleBookNow(room)}>{t('book_now')}</Button>
                          </div>
                        </div>
                      )
                    })
                  ) : checkinDate && checkoutDate ? (
                    <p className="text-graphite-secondary">{t('no_rooms_found')}</p>
                  ) : (
                     <p className="text-graphite-secondary">{t('select_dates_to_view_rooms')}</p>
                  )}
                </div>
              </div>
            </aside>
          </div>
        </div>
      </div>
    </>
  );
};

export default HotelDetailPage;
