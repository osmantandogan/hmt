
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Lock, Hotel, User, Phone, Hash } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { toast } from '@/components/ui/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useNavigate } from 'react-router-dom';

const GoogleIcon = (props) => (
  <svg viewBox="0 0 48 48" {...props}>
    <path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12s5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24s8.955,20,20,20s20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z" />
    <path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z" />
    <path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z" />
    <path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571l6.19,5.238C42.021,35.596,44,30.138,44,24C44,22.659,43.862,21.35,43.611,20.083z" />
  </svg>
);

const LoginPage = ({ initialTab = 'signin' }) => {
  const { signIn, signUp, signInWithGoogle, signInWithPhone, verifyOtp, signUpWithPhone, verifyPhoneSignUp } = useAuth();
  const [activeTab, setActiveTab] = useState(initialTab);
  const [signInEmail, setSignInEmail] = useState('');
  const [signInPassword, setSignInPassword] = useState('');
  
  const [signUpEmail, setSignUpEmail] = useState('');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [signUpFullName, setSignUpFullName] = useState('');
  
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const [signUpPhone, setSignUpPhone] = useState('');
  const [signUpOtp, setSignUpOtp] = useState('');
  const [signUpOtpSent, setSignUpOtpSent] = useState(false);
  const [signUpPhoneFullName, setSignUpPhoneFullName] = useState('');
  const navigate = useNavigate();


  const handleLogin = async (e) => {
    e.preventDefault();
    if (!signInEmail || !signInPassword) {
      toast({ title: "Eksik Bilgi", description: "Lütfen e-posta ve şifrenizi girin.", variant: "destructive" });
      return;
    }
    setLoading(true);
    const { error } = await signIn(signInEmail, signInPassword);
    setLoading(false);
    if (!error) {
      toast({ title: "Giriş Başarılı! 🎉", description: `Tekrar hoş geldiniz!` });
    }
  };

  const handleEmailSignUp = async (e) => {
    e.preventDefault();
    if (!signUpEmail || !signUpPassword || !signUpFullName) {
      toast({ title: "Eksik Bilgi", description: "Lütfen tüm alanları doldurun.", variant: "destructive" });
      return;
    }
    setLoading(true);
    const { error } = await signUp(signUpEmail, signUpPassword, {
      data: { full_name: signUpFullName, role: 'customer' }
    });
    setLoading(false);
    if (!error) {
      toast({ title: "Kayıt Başarılı! 🎉", description: "Hesabınız oluşturuldu. Lütfen e-postanızı doğrulayın." });
      setSignUpEmail('');
      setSignUpPassword('');
      setSignUpFullName('');
    }
  };

  const handleGoogleSignIn = async () => {
    setLoading(true);
    await signInWithGoogle();
    setLoading(false);
  };

  const handlePhoneSignIn = async (e) => {
    e.preventDefault();
    if (!phone) {
      toast({ title: "Eksik Bilgi", description: "Lütfen telefon numaranızı girin.", variant: "destructive" });
      return;
    }
    setLoading(true);
    const { error } = await signInWithPhone(phone);
    setLoading(false);
    if (!error) {
      setOtpSent(true);
      toast({ title: "Kod Gönderildi", description: "Telefonunuza bir doğrulama kodu gönderdik." });
    }
  };

  const handleVerifyOtp = async (e) => {
    e.preventDefault();
    if (!otp) {
      toast({ title: "Eksik Bilgi", description: "Lütfen doğrulama kodunu girin.", variant: "destructive" });
      return;
    }
    setLoading(true);
    const { error } = await verifyOtp(phone, otp);
    setLoading(false);
    if (!error) {
      toast({ title: "Giriş Başarılı! 🎉", description: "Telefonla başarıyla giriş yaptınız." });
    } else {
      setOtp('');
    }
  };

  const handlePhoneSignUpRequest = async (e) => {
    e.preventDefault();
    if (!signUpPhone || !signUpPhoneFullName) {
      toast({ title: "Eksik Bilgi", description: "Lütfen adınızı ve telefon numaranızı girin.", variant: "destructive" });
      return;
    }
    setLoading(true);
    const { error } = await signUpWithPhone(signUpPhone);
    setLoading(false);
    if (!error) {
      setSignUpOtpSent(true);
      toast({ title: "Kod Gönderildi", description: "Telefonunuza bir doğrulama kodu gönderdik." });
    }
  };

  const handlePhoneSignUpVerify = async (e) => {
    e.preventDefault();
    if (!signUpOtp) {
      toast({ title: "Eksik Bilgi", description: "Lütfen doğrulama kodunu girin.", variant: "destructive" });
      return;
    }
    setLoading(true);
    const { error } = await verifyPhoneSignUp(signUpPhone, signUpOtp, signUpPhoneFullName);
    setLoading(false);
    if (!error) {
      toast({ title: "Kayıt Başarılı! 🎉", description: "Hesabınız başarıyla oluşturuldu." });
      setSignUpPhone('');
      setSignUpOtp('');
      setSignUpPhoneFullName('');
      setSignUpOtpSent(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-ivory">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="bg-white rounded-2xl p-8 w-full max-w-md shadow-lg"
      >
        <div className="text-center mb-8">
          <div className="inline-block bg-gradient-to-br from-brand-green-dark to-brand-green-light p-4 rounded-2xl mb-4">
            <Hotel className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-brand-green-dark mb-2">HealMedy</h1>
          <p className="text-graphite-secondary">Lüks Konaklama Platformu</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="signin">Giriş Yap</TabsTrigger>
            <TabsTrigger value="phonesignin">Telefonla Giriş</TabsTrigger>
            <TabsTrigger value="signup">Hesap Oluştur</TabsTrigger>
          </TabsList>
          
          <TabsContent value="signin">
            <form onSubmit={handleLogin} className="space-y-6 mt-6">
              <div>
                <label className="block text-sm font-medium text-graphite mb-2">E-posta</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input type="email" value={signInEmail} onChange={(e) => setSignInEmail(e.target.value)} className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-brand-green-light focus:outline-none transition-colors" placeholder="personel@healmedy.com" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-graphite mb-2">Şifre</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input type="password" value={signInPassword} onChange={(e) => setSignInPassword(e.target.value)} className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-brand-green-light focus:outline-none transition-colors" placeholder="••••••••" />
                </div>
              </div>
              <Button type="submit" disabled={loading} className="w-full py-6 text-lg bg-brand-green-dark hover:bg-brand-green-dark/90 text-white">
                {loading ? 'Giriş Yapılıyor...' : 'Giriş Yap'}
              </Button>
            </form>
            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center"><span className="w-full border-t"></span></div>
              <div className="relative flex justify-center text-xs uppercase"><span className="bg-white px-2 text-muted-foreground">Veya</span></div>
            </div>
            <Button variant="outline" onClick={handleGoogleSignIn} disabled={loading} className="w-full py-6 text-lg">
              <GoogleIcon className="mr-2 h-5 w-5" />
              Google ile Giriş Yap
            </Button>
          </TabsContent>

          <TabsContent value="phonesignin">
            {!otpSent ? (
              <form onSubmit={handlePhoneSignIn} className="space-y-6 mt-6">
                <div>
                  <label className="block text-sm font-medium text-graphite mb-2">Telefon Numarası</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-brand-green-light focus:outline-none transition-colors" placeholder="+90 555 123 4567" />
                  </div>
                </div>
                <Button type="submit" disabled={loading} className="w-full py-6 text-lg bg-brand-green-dark hover:bg-brand-green-dark/90 text-white">
                  {loading ? 'Kod Gönderiliyor...' : 'Doğrulama Kodu Gönder'}
                </Button>
              </form>
            ) : (
              <form onSubmit={handleVerifyOtp} className="space-y-6 mt-6">
                <div>
                  <label className="block text-sm font-medium text-graphite mb-2">Doğrulama Kodu</label>
                  <div className="relative">
                    <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input type="text" value={otp} onChange={(e) => setOtp(e.target.value)} className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-brand-green-light focus:outline-none transition-colors" placeholder="123456" />
                  </div>
                </div>
                <Button type="submit" disabled={loading} className="w-full py-6 text-lg bg-brand-green-dark hover:bg-brand-green-dark/90 text-white">
                  {loading ? 'Doğrulanıyor...' : 'Giriş Yap'}
                </Button>
                 <Button variant="link" onClick={() => setOtpSent(false)} className="w-full text-brand-green-dark">
                  Telefon numarasını değiştir
                </Button>
              </form>
            )}
          </TabsContent>

          <TabsContent value="signup">
            <Tabs defaultValue="email-signup" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="email-signup">E-posta ile</TabsTrigger>
                <TabsTrigger value="phone-signup">Telefon ile</TabsTrigger>
              </TabsList>
              <TabsContent value="email-signup">
                <form onSubmit={handleEmailSignUp} className="space-y-6 mt-6">
                  <div>
                    <label className="block text-sm font-medium text-graphite mb-2">Ad Soyad</label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input type="text" value={signUpFullName} onChange={(e) => setSignUpFullName(e.target.value)} className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-brand-green-light focus:outline-none transition-colors" placeholder="Ahmet Yılmaz" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-graphite mb-2">E-posta</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input type="email" value={signUpEmail} onChange={(e) => setSignUpEmail(e.target.value)} className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-brand-green-light focus:outline-none transition-colors" placeholder="ornek@eposta.com" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-graphite mb-2">Şifre</label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input type="password" value={signUpPassword} onChange={(e) => setSignUpPassword(e.target.value)} className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-brand-green-light focus:outline-none transition-colors" placeholder="••••••••" />
                    </div>
                  </div>
                  <Button type="submit" disabled={loading} className="w-full py-6 text-lg bg-brand-green-dark hover:bg-brand-green-dark/90 text-white">
                    {loading ? 'Hesap Oluşturuluyor...' : 'Hesap Oluştur'}
                  </Button>
                </form>
              </TabsContent>
              <TabsContent value="phone-signup">
                {!signUpOtpSent ? (
                  <form onSubmit={handlePhoneSignUpRequest} className="space-y-6 mt-6">
                    <div>
                      <label className="block text-sm font-medium text-graphite mb-2">Ad Soyad</label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input type="text" value={signUpPhoneFullName} onChange={(e) => setSignUpPhoneFullName(e.target.value)} className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-brand-green-light focus:outline-none transition-colors" placeholder="Ahmet Yılmaz" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-graphite mb-2">Telefon Numarası</label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input type="tel" value={signUpPhone} onChange={(e) => setSignUpPhone(e.target.value)} className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-brand-green-light focus:outline-none transition-colors" placeholder="+90 555 123 4567" />
                      </div>
                    </div>
                    <Button type="submit" disabled={loading} className="w-full py-6 text-lg bg-brand-green-dark hover:bg-brand-green-dark/90 text-white">
                      {loading ? 'Kod Gönderiliyor...' : 'Doğrulama Kodu Gönder'}
                    </Button>
                  </form>
                ) : (
                  <form onSubmit={handlePhoneSignUpVerify} className="space-y-6 mt-6">
                    <div>
                      <label className="block text-sm font-medium text-graphite mb-2">Doğrulama Kodu</label>
                      <div className="relative">
                        <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input type="text" value={signUpOtp} onChange={(e) => setSignUpOtp(e.target.value)} className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-brand-green-light focus:outline-none transition-colors" placeholder="123456" />
                      </div>
                    </div>
                    <Button type="submit" disabled={loading} className="w-full py-6 text-lg bg-brand-green-dark hover:bg-brand-green-dark/90 text-white">
                      {loading ? 'Hesap Doğrulanıyor...' : 'Hesabı Oluştur'}
                    </Button>
                    <Button variant="link" onClick={() => setSignUpOtpSent(false)} className="w-full text-brand-green-dark">
                      Telefon numarasını değiştir
                    </Button>
                  </form>
                )}
              </TabsContent>
            </Tabs>
          </TabsContent>
        </Tabs>

        <div className="mt-6 text-center">
          <button onClick={() => navigate('/')} className="text-brand-green-dark hover:text-brand-green-dark/80 text-sm font-medium">
            ← Ana Sayfaya Dön
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default LoginPage;
