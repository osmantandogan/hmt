import React, { useMemo } from 'react';
import { useBookingData } from '@/hooks/useBookingData';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { MapPin, Clock, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCurrency } from '@/components/layouts/PublicLayout';
import { Helmet } from 'react-helmet';

const TourCard = ({ tour }) => {
  const { i18n, t } = useTranslation();
  const { currency, exchangeRate } = useCurrency();

  const name = tour[`name_${i18n.language}`] || tour.name_en;
  const highlights = tour[`highlights_${i18n.language}`] || tour.highlights_en;
  
  // Find the default price rule
  const priceRule = tour.tour_price_rules && tour.tour_price_rules.length > 0 ? tour.tour_price_rules[0] : null;

  const getPriceDisplay = () => {
    if (!priceRule) return null;

    let price = priceRule.base_price_adult;
    if (priceRule.currency === 'TRY' && currency === 'EUR') {
      price /= exchangeRate;
    } else if (priceRule.currency === 'EUR' && currency === 'TRY') {
      price *= exchangeRate;
    }
    const formattedPrice = price.toLocaleString(i18n.language === 'tr' ? 'tr-TR' : 'en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0,
    });
    return <span className="text-graphite">{t('from_price_person', { amount: formattedPrice })}</span>;
  };

  return (
    <motion.div
      className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300 group flex flex-col"
      whileHover={{ y: -5 }}
    >
      <div className="relative">
        <img
          src={tour.hero_url || 'https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?auto=format&fit=crop&w=800&q=60'}
          alt={name}
          className="w-full h-56 object-cover transition-transform duration-300 group-hover:scale-105"
        />
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="font-serif text-xl font-medium text-graphite pr-2 mb-2">{name}</h3>
        <div className="flex items-center text-sm text-graphite-secondary mb-4">
          <MapPin className="w-4 h-4 mr-1.5" />
          <span>{tour.city}, {tour.country}</span>
        </div>
        <ul className="text-sm text-graphite-secondary mb-4 flex-grow space-y-1">
          {(highlights || []).slice(0, 2).map((highlight, index) => (
            <li key={index} className="flex items-start">
              <span className="text-brand-green-dark mr-2 mt-1">&#10003;</span>
              <span>{highlight}</span>
            </li>
          ))}
        </ul>
        <div className="flex justify-between items-center text-sm text-graphite-secondary mb-4">
          <div className="flex items-center gap-1"><Clock className="w-4 h-4" /> {tour.duration_minutes} {t('minutes')}</div>
          <div className="flex items-center gap-1"><Users className="w-4 h-4" /> {t('up_to_guests', {count: tour.max_group_size})}</div>
        </div>
        <div className="flex justify-between items-center mt-auto">
          <div className="text-lg font-bold">{getPriceDisplay()}</div>
          <Button variant="outline" size="sm">{t('details_button')}</Button>
        </div>
      </div>
    </motion.div>
  );
};

const ToursPage = () => {
  const { tours, loading } = useBookingData();
  const { t } = useTranslation();

  const activeTours = useMemo(() => {
    return tours.filter(tour => tour.status === 'active');
  }, [tours]);

  return (
    <>
      <Helmet>
        <title>{t('tours_page_title')} - HealMedy Travel</title>
        <meta name="description" content={t('tours_page_meta_desc')} />
      </Helmet>
      <div className="bg-ivory">
        <div className="container mx-auto px-4 py-16">
          <header className="text-center mb-12">
            <h1 className="text-5xl font-serif text-graphite mb-4">{t('discover_tours')}</h1>
            <p className="text-lg text-graphite-secondary max-w-2xl mx-auto">{t('tours_subtitle')}</p>
          </header>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="bg-white/50 rounded-lg shadow-sm animate-pulse">
                  <div className="w-full h-56 bg-gray-300 rounded-t-lg"></div>
                  <div className="p-6">
                    <div className="h-6 w-3/4 bg-gray-300 rounded mb-2"></div>
                    <div className="h-4 w-1/2 bg-gray-300 rounded"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {activeTours.map(tour => (
                <TourCard key={tour.id} tour={tour} />
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default ToursPage;